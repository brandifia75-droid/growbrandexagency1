const fs = require('fs');

// Patch Navbar.tsx
let navbarCode = fs.readFileSync('src/components/home/Navbar.tsx', 'utf8');
const defaultLinksRegex = /const defaultLinks = \[/;
if (navbarCode.match(defaultLinksRegex) && !navbarCode.includes('label: "Home"')) {
    navbarCode = navbarCode.replace(defaultLinksRegex, `const defaultLinks = [\n  { label: "Home", href: "/", route: true },`);
}
const navbarMergeLogic = `if (savedNav && !currentNav.find((item) => item.href === "/")) {
    currentNav.unshift({ label: "Home", href: "/", route: true, visible: true } as any);
  }
  if (savedNav && !currentNav.find((item) => item.href === "/#why-choose-us")) {`;
if (!navbarCode.includes('item.href === "/"')) {
    navbarCode = navbarCode.replace(/if \(savedNav && !currentNav\.find\(\(item\) => item\.href === "\/#why-choose-us"\)\) \{/, navbarMergeLogic);
}
fs.writeFileSync('src/components/home/Navbar.tsx', navbarCode);


// Patch navigation.tsx
let navCode = fs.readFileSync('src/routes/admin/navigation.tsx', 'utf8');
const defaultNavRegex = /export const defaultNavigation = \[/;
if (navCode.match(defaultNavRegex) && !navCode.includes('label: "Home"')) {
    navCode = navCode.replace(defaultNavRegex, `export const defaultNavigation = [\n  { label: "Home", href: "/", route: true, visible: true },`);
}
const navMergeLogic = `const mergedItems = [...savedItems];
      if (!mergedItems.find(i => i.href === "/")) {
         mergedItems.unshift({ label: "Home", href: "/", route: true, visible: true });
      }
      if (!mergedItems.find(i => i.href === "/#why-choose-us")) {`;
if (!navCode.includes('i.href === "/"')) {
    navCode = navCode.replace(/const mergedItems = \[\.\.\.savedItems\];\s*if \(!mergedItems\.find\(i => i\.href === "\/#why-choose-us"\)\) \{/, navMergeLogic);
}
fs.writeFileSync('src/routes/admin/navigation.tsx', navCode);
