const fs = require('fs');
let code = fs.readFileSync('src/routes/about.tsx', 'utf8');

const importsToAdd = `
import { TextImageSection, CTASection } from "@/components/sections/DynamicSection";

const DEFAULT_ABOUT_SECTIONS = [
  { id: "about-hero", type: "AboutHero", visible: true, order: 1, isCore: true },
  { id: "about-story", type: "AboutStory", visible: true, order: 2, isCore: true },
  { id: "about-timeline", type: "AboutTimeline", visible: true, order: 3, isCore: true },
  { id: "about-skills", type: "AboutSkills", visible: true, order: 4, isCore: true },
  { id: "about-cta", type: "AboutCTA", visible: true, order: 5, isCore: true }
];
`;

code = code.replace(/function AboutPage\(\) \{/, importsToAdd + '\nfunction AboutPage() {');

// The tricky part is replacing the static render with the dynamic one while keeping the inner variables defined.
// The inner components like `<Reveal className="text-center">` (hero), `<section className="mt-20 ...">` (story) 
// are tightly coupled with the constants defined in AboutPage(). 

// I will extract the jsx chunks and render them in the switch case.

const renderLogicMatch = code.match(/return \(\s*<div className="relative min-h-screen">[\s\S]*?<\/div>\s*\);/);
let renderLogic = renderLogicMatch[0];

const heroChunk = renderLogic.match(/<Reveal className="text-center">[\s\S]*?<\/Reveal>/)[0];
const storyChunk = renderLogic.match(/<section className="mt-20 grid gap-6 lg:grid-cols-3">[\s\S]*?<\/section>/)[0];
const timelineChunk = renderLogic.match(/<section className="mt-24">[\s\S]*?<\/section>/)[0];
const skillsChunk = renderLogic.match(/<section className="mt-16">[\s\S]*?<\/section>/)[0];
const ctaChunk = renderLogic.match(/<Reveal className="mt-20 text-center" delay=\{80\}>[\s\S]*?<\/Reveal>/)[0];

const newRenderLogic = `
  let sections = (settings?.page_sections?.about as any[]) || DEFAULT_ABOUT_SECTIONS;
  sections = [...sections].sort((a, b) => a.order - b.order);

  return (
    <div className="relative min-h-screen">
      <GlowBackground />
      <Navbar />
      <main className="px-5 pb-24 pt-32 sm:px-8 sm:pt-40">
        <div className="mx-auto max-w-7xl">
          {sections.map(sec => {
            if (!sec.visible) return null;
            switch (sec.type) {
              case "AboutHero": return <React.Fragment key={sec.id}>${heroChunk}</React.Fragment>;
              case "AboutStory": return <React.Fragment key={sec.id}>${storyChunk}</React.Fragment>;
              case "AboutTimeline": return <React.Fragment key={sec.id}>${timelineChunk}</React.Fragment>;
              case "AboutSkills": return <React.Fragment key={sec.id}>${skillsChunk}</React.Fragment>;
              case "AboutCTA": return <React.Fragment key={sec.id}>${ctaChunk}</React.Fragment>;
              case "TextImage": return <TextImageSection key={sec.id} payload={sec.payload} />;
              case "CustomCTA": return <CTASection key={sec.id} payload={sec.payload} />;
              default: return null;
            }
          })}
        </div>
      </main>
      <Footer />
    </div>
  );
`;

code = code.replace(renderLogicMatch[0], newRenderLogic);

// Ensure React is imported
if (!code.includes('import React')) {
  code = `import React from 'react';\n` + code;
}

fs.writeFileSync('src/routes/about.tsx', code);
