const fs = require('fs');

const path = 'src/routes/admin/navigation.tsx';
let code = fs.readFileSync(path, 'utf8');

const defaultNavRegex = /export const defaultNavigation = \[\s*\{ label: "Services", href: "\/services", route: true \},\s*\{ label: "About", href: "\/about", route: true \},/m;
code = code.replace(defaultNavRegex, `export const defaultNavigation = [
  { label: "Services", href: "/services", route: true },
  { label: "Why Choose Us", href: "/#why-choose-us", route: false, visible: true },
  { label: "About", href: "/about", route: true },`);

const useEffectRegex = /if \(settings\?\.\[\'navigation\'\]\?\.\['items'\]\) \{\s*setItems\(settings\.\[\'navigation\'\]\.\[\'items\'\] as NavItem\[\]\);\s*\}/m;

const mergeLogic = `if (settings?.['navigation']?.['items']) {
      const savedItems = settings['navigation']['items'] as NavItem[];
      const mergedItems = [...savedItems];
      if (!mergedItems.find(i => i.href === "/#why-choose-us")) {
         const servicesIndex = mergedItems.findIndex(i => i.href === "/services");
         const insertIdx = servicesIndex !== -1 ? servicesIndex + 1 : 0;
         mergedItems.splice(insertIdx, 0, { label: "Why Choose Us", href: "/#why-choose-us", route: false, visible: true });
      }
      setItems(mergedItems);
    }`;

code = code.replace(useEffectRegex, mergeLogic);

fs.writeFileSync(path, code);
