
INSERT INTO public.projects (title, category, description, image_url, featured, sort_order) VALUES
('Nexa Supply','Graphic Designing','Complete brand identity, logo system and packaging for a B2B supply brand.','/api/public/img/work/work-1.jpg',true,1),
('Orbit Finance','Web Development','Designed and built a fast, conversion-focused fintech marketing site.','/api/public/img/work/work-2.jpg',true,2),
('Lumen Studio','AI Photoshoot','AI-generated product photography set replacing a full studio shoot.','/api/public/img/work/work-3.jpg',true,3),
('Vera Skincare','AI UGC Ads','12 AI creator-style video ads that cut cost per acquisition by 38%.','/api/public/img/work/work-4.jpg',true,4),
('Northline','Social Media Management','Full-funnel content calendar and community management across 3 channels.','/api/public/img/work/work-5.jpg',true,5),
('Kite & Co.','Graphic Designing','Editorial-style visual system for a lifestyle brand relaunch.','/api/public/img/work/work-6.jpg',true,6),
('Obsidian Serum','AI Photoshoot','Moody AI hero imagery for a premium skincare product launch.','/api/public/img/work/work-7.jpg',false,7),
('Pulse Analytics','Web Development','Built a dark-mode SaaS dashboard and marketing site from scratch.','/api/public/img/work/work-8.jpg',false,8),
('Atlas Social','Social Media Management','Rebuilt the feed aesthetic and grew engagement 4x in 90 days.','/api/public/img/work/work-9.jpg',false,9),
('Monolith Labs','Graphic Designing','Stationery, packaging and logo mark for a premium tech studio.','/api/public/img/work/work-10.jpg',false,10),
('Bloom Wellness','AI UGC Ads','Short-form vertical UGC ad set built entirely with AI creators.','/api/public/img/work/work-11.jpg',false,11),
('Vault Apparel','Web Development','Headless e-commerce storefront with a 2.1s faster load time.','/api/public/img/work/work-12.jpg',false,12);

UPDATE public.site_settings SET value = jsonb_set(value, '{logo_url}', '"/api/public/img/brand/logo.png"') WHERE key = 'branding';
