CREATE TABLE public.submissions (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  phone text not null,
  service text not null,
  message text not null,
  status text not null default 'unread',
  created_at timestamp with time zone default now()
);

ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public users can insert submissions" ON public.submissions
  FOR INSERT TO public, anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Admins can view and manage submissions" ON public.submissions
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
