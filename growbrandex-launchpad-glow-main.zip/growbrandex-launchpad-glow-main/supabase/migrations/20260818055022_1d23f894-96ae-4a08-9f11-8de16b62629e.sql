
CREATE TYPE public.app_role AS ENUM ('admin');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "authenticated can read roles" ON public.user_roles FOR SELECT TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- SETTINGS -------------------------------------------------------------
CREATE TABLE public.site_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_settings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_settings TO authenticated;
GRANT ALL ON public.site_settings TO service_role;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read settings" ON public.site_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admins write settings" ON public.site_settings FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER t_site_settings_updated BEFORE UPDATE ON public.site_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- PROJECTS -------------------------------------------------------------
CREATE TABLE public.projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  category text NOT NULL,
  image_url text NOT NULL DEFAULT '',
  featured boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.projects TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects TO authenticated;
GRANT ALL ON public.projects TO service_role;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read projects" ON public.projects FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admins write projects" ON public.projects FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER t_projects_updated BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- SERVICES -------------------------------------------------------------
CREATE TABLE public.services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  short_description text NOT NULL DEFAULT '',
  long_description text NOT NULL DEFAULT '',
  icon text NOT NULL DEFAULT 'Sparkles',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.services TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.services TO authenticated;
GRANT ALL ON public.services TO service_role;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read services" ON public.services FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admins write services" ON public.services FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER t_services_updated BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- AWARDS ---------------------------------------------------------------
CREATE TABLE public.awards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  year text NOT NULL DEFAULT '',
  source text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.awards TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.awards TO authenticated;
GRANT ALL ON public.awards TO service_role;
ALTER TABLE public.awards ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read awards" ON public.awards FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admins write awards" ON public.awards FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER t_awards_updated BEFORE UPDATE ON public.awards FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- TESTIMONIALS ---------------------------------------------------------
CREATE TABLE public.testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote text NOT NULL,
  author text NOT NULL,
  role text NOT NULL DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.testimonials TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.testimonials TO authenticated;
GRANT ALL ON public.testimonials TO service_role;
ALTER TABLE public.testimonials ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read testimonials" ON public.testimonials FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admins write testimonials" ON public.testimonials FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER t_testimonials_updated BEFORE UPDATE ON public.testimonials FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- SEED -----------------------------------------------------------------
INSERT INTO public.site_settings (key, value) VALUES
('theme', '{"name":"neon-black"}'),
('branding', '{"logo_url":"","site_name":"GrowBrandex"}'),
('contact', '{"email":"hello@growbrandex.com","whatsapp":"+1 (555) 012-3456","instagram":"https://instagram.com/growbrandex","facebook":"https://facebook.com/growbrandex","linkedin":"https://linkedin.com/company/growbrandex","twitter":"https://twitter.com/growbrandex","youtube":""}'),
('stats', '{"projects":150,"clients":80,"services":5,"rating":4.9}'),
('home', '{"heroEyebrow":"Full-service digital growth agency","heroTitle":"We Build Brands","heroHighlight":"That Grow","heroSubtitle":"GrowBrandex helps business owners build and scale their brand online with design, development and AI-powered content — all under one roof.","ctaPrimary":"Start a Project","ctaSecondary":"View Our Work","statsTitle":"Numbers that speak","servicesEyebrow":"What we do","servicesTitle":"Five services, one growth engine","servicesSubtitle":"Everything a modern brand needs to look sharp and sell more.","workEyebrow":"Featured work","workTitle":"Selected projects","workSubtitle":"A snapshot of brands we have designed, built and scaled.","testimonialsEyebrow":"Testimonials","testimonialsTitle":"What clients say","brandsTitle":"Brands we have worked with","ctaTitle":"Ready to grow your brand?","ctaSubtitle":"Tell us where you want to be in 12 months and we will build the system to get you there.","ctaButton":"Start a Project"}'),
('portfolio', '{"eyebrow":"Portfolio","title":"Our work","subtitle":"Browse projects across all five of our service categories.","ctaTitle":"Like what you see?","ctaSubtitle":"Let us build something just as strong for your brand.","lightboxButton":"Start a Similar Project"}'),
('about', '{"eyebrow":"About us","title":"We build brand growth systems","story":"GrowBrandex started as a small team helping local business owners look more professional online. Over time, we expanded into a full-service digital agency covering design, development, and AI-powered content, because our clients kept asking us to handle more of their growth in one place.","difference":"What makes us different is that we do not just deliver a design or a video — we build a complete brand growth system, combining creative, technical and AI-driven content so business owners can focus on running their business while we handle their online presence.","mission":"Our mission is to help business owners grow real, recognizable brands without needing five different freelancers.","timelineTitle":"Our journey","skillsTitle":"Where we are strongest"}'),
('services_page', '{"eyebrow":"Services","title":"Everything your brand needs to grow","subtitle":"Five services designed to work together as one growth system.","quoteButton":"Get a Quote","ctaTitle":"Not sure where to start?","ctaSubtitle":"Tell us about your business and we will recommend the right mix."}'),
('awards_page', '{"eyebrow":"Awards & achievements","title":"Milestones worth celebrating","subtitle":"Recognition and results we have earned along the way."}'),
('contact_page', '{"eyebrow":"Contact","title":"Let us start something","subtitle":"Tell us about your brand and we will get back to you within one business day.","address":"Remote-first, serving clients worldwide","hours":"Mon–Fri, 9am–6pm"}'),
('brands', '{"items":["Nexa Supply","Orbit Finance","Lumen Studio","Vera Skincare","Northline","Kite & Co.","Bluepeak","Formworks"]}'),
('timeline', '{"items":[{"title":"Founded as a small design team","description":"Helping local business owners look professional online."},{"title":"Added web development services","description":"Fast, responsive websites built to convert."},{"title":"Introduced AI-powered content production","description":"Studio-quality visuals without a studio."},{"title":"Expanded into full social media management","description":"Planning, posting and growth handled end to end."},{"title":"Became a 5-service full digital agency","description":"One partner for the whole brand growth system."}]}'),
('skills', '{"items":[{"label":"Graphic Designing","value":95},{"label":"Web Development","value":92},{"label":"AI Photoshoot","value":88},{"label":"AI UGC Ads","value":90},{"label":"Social Media Management","value":86}]}');

INSERT INTO public.services (title, short_description, long_description, icon, sort_order) VALUES
('Graphic Designing','Brand identity, logos and creatives that look professional everywhere.','Brand identity, logos, social media creatives, and marketing design assets that make a business look professional everywhere it shows up.','Brush',1),
('Web Development','Modern, responsive websites built to convert visitors into clients.','Modern, responsive websites and portfolios built to convert visitors into clients, fully functional on every device.','Code2',2),
('AI Photoshoot','Studio-quality product and portrait imagery without a physical shoot.','Professional, studio-quality product and portrait photography generated with AI, without needing a physical studio shoot.','Camera',3),
('AI UGC Ads','Scroll-stopping AI-generated UGC-style video ads.','Realistic, scroll-stopping AI-generated user-generated-content style video ads for social media and paid campaigns.','Clapperboard',4),
('Social Media Management','Planning, content, posting and growth across your channels.','Full planning, content creation, posting, and growth management across a business social media channels.','Share2',5);

INSERT INTO public.awards (title, year, source, description, sort_order) VALUES
('100 Projects Delivered','2021','Client milestone','Proof that our process scales beyond one-off projects.',1),
('Top Rated Agency Badge','2022','Freelance marketplace','Awarded for consistent 5-star delivery across client work.',2),
('4.9/5 Average Client Rating','2023','Verified client reviews','Sustained quality across 80+ brands we have partnered with.',3),
('AI Content Innovator Feature','2023','Industry community','Recognised for early adoption of AI-driven brand content.',4),
('150+ Projects Delivered','2024','Client milestone','A decade-worth of output packed into a few focused years.',5),
('Community Spotlight','2024','Digital marketing community','Featured for helping small business owners compete online.',6);

INSERT INTO public.testimonials (quote, author, role, sort_order) VALUES
('GrowBrandex rebuilt our brand from scratch and our inbound leads tripled in four months.','Amelia Hart','Founder, Nexa Supply',1),
('The AI product shots saved us an entire studio budget and honestly looked better.','Daniel Okafor','Marketing Lead, Vera Skincare',2),
('One team for design, web and social. It finally feels like our brand has a direction.','Priya Raman','Owner, Kite & Co.',3);
