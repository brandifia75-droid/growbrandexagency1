# GrowBrandex Launchpad

I want you to design a full, detailed Home Page for my digital agency's website. I've attached our logo — please use it in the navigation bar and match the site's color palette to it (black background, neon/lime green accent, white text). My agency is called GrowBrandex, a full-service digital growth agency helping business owners build and scale their brand online. Our tagline is "We Build Brands That Grow." We have delivered 150+ projects, worked with 80+ happy clients, and maintain a 4.9 out of 5 average client rating. (Use these as realistic placeholder stats for now — I will update the real numbers later through the Admin Panel.) Build the page with the following sections, in this order. 1) A hero section with our logo and headline on one side and a short supporting line on the other, with two call to action buttons: "Start a Project" and "View Our Work." 2) A stats section showing our key numbers (150+ Projects Delivered, 80+ Happy Clients, 5 Services Offered, 4.9 Average Rating) as animated counters that count up when the visitor scrolls to them. 3) A services teaser section previewing all five of our services — Graphic Designing, Web Development, AI Photoshoot, AI UGC Ads, and Social Media Management — each with an icon and a one line description, and a "Get a Quote" button on each. 4) A featured work section with a small gallery of sample project thumbnails in a grid, each with a hover zoom effect, and a "View Full Portfolio" button below the gallery linking to a dedicated Portfolio page. 5) A short testimonials section with two or three sample client quotes in sliding cards. 6) A section showing logos or names of a few brands we have worked with, in a smoothly sliding marquee style row. 7) A closing call to action section inviting visitors to start a project with us, and a footer with quick links and social icons. Visually, use a bold black background with a glowing neon/lime green accent color and clean white text, modern bold sans-serif fonts, and a premium, highgrowth tech-agency mood. For the background animation, use soft, blurred glowing green gradient shapes or particles that slowly drift and pulse, so the page never feels flat or static. Do not use any moving line, scanning bar, or sweeping light effect anywhere on the page, since that kind of motion feels distracting rather than premium. For animations, make the whole page feel alive: the logo and headline should gently reveal with a smooth fade when the page loads, every section below the hero should fade and slide into view one after another as the visitor scrolls down rather than appearing all at once, the stat counters should animate upward, work thumbnails should smoothly zoom or lift on hover, the testimonials should slide automatically or on click, and the brand logos should scroll in an endless smooth loop. Keep all background motion soft and blurred, never a sharp moving line or scanning effect. Make sure the entire page is fully responsive and looks great on desktop, laptop, tablet, and mobile phone screens. Once the Home Page is ready, package everything into one zip file for me to download, show it to me, and wait for my next instructions before building any other page.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/e209f566-ee0d-4744-8247-aeb30572957a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
