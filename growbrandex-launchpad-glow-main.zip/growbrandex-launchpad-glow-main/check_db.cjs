const fs = require('fs');

const env = fs.readFileSync('.env', 'utf8').split('\n').reduce((acc, line) => {
  const [key, ...value] = line.split('=');
  if (key) acc[key.trim()] = value.join('=').trim().replace(/['"]/g, '');
  return acc;
}, {});

const supabaseUrl = env.VITE_SUPABASE_URL;
const supabaseAnonKey = env.VITE_SUPABASE_PUBLISHABLE_KEY;

async function check() {
  const tables = ['submissions', 'inquiries', 'contacts', 'messages', 'contact_inquiries', 'contact_submissions', 'website_sections', 'site_content', 'settings', 'projects', 'testimonials'];
  for (const table of tables) {
    const res = await fetch(`${supabaseUrl}/rest/v1/${table}?select=id&limit=1`, {
      headers: {
        'apikey': supabaseAnonKey
      }
    });
    if (!res.ok) {
      console.log(`Table '${table}' error: ${res.status} - ${await res.text()}`);
    } else {
      console.log(`Table '${table}' EXISTS!`);
    }
  }
}
check();
