const fs = require('fs');
let code = fs.readFileSync('src/routes/admin/navigation.tsx', 'utf8');

code = code.replace(/const temp = newItems\[index - 1\];/g, "const temp = newItems[index - 1] as NavItem;");
code = code.replace(/newItems\[index - 1\] = newItems\[index\];/g, "newItems[index - 1] = newItems[index] as NavItem;");
code = code.replace(/newItems\[index\] = temp;/g, "newItems[index] = temp as NavItem;");

code = code.replace(/const temp = newItems\[index \+ 1\];/g, "const temp = newItems[index + 1] as NavItem;");
code = code.replace(/newItems\[index \+ 1\] = newItems\[index\];/g, "newItems[index + 1] = newItems[index] as NavItem;");

code = code.replace(/newItems\[index\] = \{ \.\.\.newItems\[index\], visible: !newItems\[index\]\.visible \};/g, 
  "newItems[index] = { ...(newItems[index] as NavItem), visible: !(newItems[index] as NavItem).visible } as NavItem;");

fs.writeFileSync('src/routes/admin/navigation.tsx', code);
