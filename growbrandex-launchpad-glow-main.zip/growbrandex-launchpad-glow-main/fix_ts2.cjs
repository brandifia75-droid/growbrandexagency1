const fs = require('fs');

function replace(file, search, replaceStr) {
  let code = fs.readFileSync(file, 'utf8');
  code = code.split(search).join(replaceStr);
  fs.writeFileSync(file, code);
}

replace('src/lib/admin.functions.ts', 'new Date(b.created_at).getTime() - new Date(a.created_at).getTime()', 'new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()');

replace('src/components/admin/SettingsForm.tsx', 'value={value as string || ""}', 'value={(value as string) || ""}');
replace('src/components/admin/SettingsForm.tsx', 'value={value}', 'value={(value as string) || ""}');

replace('src/routes/admin/images.tsx', 'value={value as string || ""}', 'value={(value as string) || ""}');
replace('src/routes/admin/images.tsx', 'value={value}', 'value={(value as string) || ""}');
replace('src/routes/admin/images.tsx', 'settings?.branding?.logo_url', 'settings?.["branding"]?.["logo_url"]');

replace('src/routes/admin/portfolio.tsx', 'value={field.value as string || ""}', 'value={(field.value as string) || ""}');
replace('src/routes/admin/portfolio.tsx', 'value={field.value}', 'value={(field.value as string) || ""}');

