const fs = require('fs');

function patchFile(path) {
  let code = fs.readFileSync(path, 'utf8');
  code = code.replace(/settings\?\.page_sections\?\.home/g, "settings?.['page_sections']?.['home']");
  code = code.replace(/settings\?\.page_sections\?\.about/g, "settings?.['page_sections']?.['about']");
  code = code.replace(/settings\?\.page_sections\?\.\[page\]/g, "settings?.['page_sections']?.[page]");
  code = code.replace(/settings\?\.page_sections\?\.\[activePage\]/g, "settings?.['page_sections']?.[activePage]");
  code = code.replace(/settings\?\.page_sections/g, "settings?.['page_sections']");
  fs.writeFileSync(path, code);
}

patchFile('src/routes/index.tsx');
patchFile('src/routes/about.tsx');
patchFile('src/components/admin/WebsiteSections.tsx');
