const fs = require('fs');

function patchFile(path) {
  let code = fs.readFileSync(path, 'utf8');
  code = code.replace(/settings\?\.navigation\?\.items/g, "settings?.['navigation']?.['items']");
  code = code.replace(/settings\?\.navigation/g, "settings?.['navigation']");
  code = code.replace(/settings\?\.branding\?\.logo_url/g, "settings?.['branding']?.['logo_url']");
  fs.writeFileSync(path, code);
}

patchFile('src/routes/admin/navigation.tsx');
patchFile('src/routes/admin/images.tsx');
