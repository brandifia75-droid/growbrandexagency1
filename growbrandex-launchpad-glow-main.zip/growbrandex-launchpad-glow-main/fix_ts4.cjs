const fs = require('fs');

function replace(file, search, replaceStr) {
  let code = fs.readFileSync(file, 'utf8');
  code = code.split(search).join(replaceStr);
  fs.writeFileSync(file, code);
}

replace('src/components/admin/SettingsForm.tsx', 'onChange(uploadData.url)', 'onChange(uploadData.url as string)');
replace('src/routes/admin/images.tsx', 'settings?.branding?.logo_url', 'settings?.["branding"]?.["logo_url"]');
replace('src/routes/admin/portfolio.tsx', 'value={field.value as string || ""}', 'value={(field.value as string) || ""}');
replace('src/routes/admin/portfolio.tsx', 'value={field.value}', 'value={(field.value as string) || ""}');

