const fs = require('fs');

const path = 'src/components/home/Navbar.tsx';
let code = fs.readFileSync(path, 'utf8');

const defaultLinksRegex = /const defaultLinks = \[\s*\{ label: "Services", href: "\/services", route: true \},\s*\{ label: "About", href: "\/about", route: true \},/m;
code = code.replace(defaultLinksRegex, `const defaultLinks = [
  { label: "Services", href: "/services", route: true },
  { label: "Why Choose Us", href: "/#why-choose-us", route: false },
  { label: "About", href: "/about", route: true },`);

const activeLinksRegex = /const savedNav = settings\?\.navigation\?\.items as typeof defaultLinks \| undefined;\s*const activeLinks = \(savedNav \|\| defaultLinks\)\.filter\(\s*\(item\) => \(item as \{ visible\?: boolean \}\)\.visible !== false,\s*\);/m;
const activeLinksRegex2 = /const savedNav = settings\?\.\[\'navigation\'\]\?\.\['items'\] as typeof defaultLinks \| undefined;\s*const activeLinks = \(savedNav \|\| defaultLinks\)\.filter\(\s*\(item\) => \(item as \{ visible\?: boolean \}\)\.visible !== false,\s*\);/m;
const activeLinksRegex3 = /const savedNav = (.*?);\s*const activeLinks = (.*?)\.filter\((.*?)\);/m;

const mergeLogic = `const savedNav = settings?.['navigation']?.['items'] as typeof defaultLinks | undefined;

  let currentNav = savedNav ? [...savedNav] : [...defaultLinks];
  if (savedNav && !currentNav.find((item) => item.href === "/#why-choose-us")) {
    const servicesIndex = currentNav.findIndex((i) => i.href === "/services");
    const insertIdx = servicesIndex !== -1 ? servicesIndex + 1 : 0;
    currentNav.splice(insertIdx, 0, { label: "Why Choose Us", href: "/#why-choose-us", route: false, visible: true } as any);
  }

  const activeLinks = currentNav.filter(
    (item) => (item as { visible?: boolean }).visible !== false,
  );`;

if (code.match(activeLinksRegex)) {
    code = code.replace(activeLinksRegex, mergeLogic);
} else if (code.match(activeLinksRegex2)) {
    code = code.replace(activeLinksRegex2, mergeLogic);
} else {
    code = code.replace(activeLinksRegex3, mergeLogic);
}


fs.writeFileSync(path, code);
