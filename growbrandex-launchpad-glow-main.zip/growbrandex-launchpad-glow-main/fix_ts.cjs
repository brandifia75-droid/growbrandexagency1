const fs = require('fs');

function replace(file, search, replace) {
  let code = fs.readFileSync(file, 'utf8');
  code = code.split(search).join(replace);
  fs.writeFileSync(file, code);
}

replace('src/components/home/Navbar.tsx', 'settings?.branding?.logo_url', 'settings?.["branding"]?.["logo_url"]');
replace('src/components/home/Navbar.tsx', 'settings?.branding?.site_name', 'settings?.["branding"]?.["site_name"]');

replace('src/components/admin/SettingsForm.tsx', 'value={value || ""}', 'value={value as string || ""}');
replace('src/components/admin/SettingsForm.tsx', 'onChange={(e) => onChange(e.target.value)}', 'onChange={(e) => onChange(e.target.value as any)}');

replace('src/routes/admin/images.tsx', 'value={value || ""}', 'value={value as string || ""}');
replace('src/routes/admin/images.tsx', 'settings?.branding?.logo_url', 'settings?.["branding"]?.["logo_url"]');

replace('src/routes/admin/portfolio.tsx', 'value={field.value}', 'value={field.value as string || ""}');

