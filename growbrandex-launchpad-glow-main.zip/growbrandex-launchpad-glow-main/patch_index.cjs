const fs = require('fs');
let code = fs.readFileSync('src/routes/index.tsx', 'utf8');

const importsToAdd = `
import { useSite } from "@/lib/site-content";
import { TextImageSection, CTASection } from "@/components/sections/DynamicSection";

const DEFAULT_HOME_SECTIONS = [
  { id: "home-hero", type: "Hero", visible: true, order: 1, isCore: true },
  { id: "home-stats", type: "Stats", visible: true, order: 2, isCore: true },
  { id: "home-services", type: "Services", visible: true, order: 3, isCore: true },
  { id: "home-why-choose-us", type: "WhyChooseUs", visible: true, order: 4, isCore: true },
  { id: "home-work", type: "Work", visible: true, order: 5, isCore: true },
  { id: "home-testimonials", type: "Testimonials", visible: true, order: 6, isCore: true },
  { id: "home-brand-marquee", type: "BrandMarquee", visible: true, order: 7, isCore: true },
  { id: "home-cta", type: "ClosingCTA", visible: true, order: 8, isCore: true },
];
`;

code = code.replace('export const Route = createFileRoute', importsToAdd + '\nexport const Route = createFileRoute');

const renderLogic = `
function Index() {
  const { settings } = useSite();
  let sections = (settings?.page_sections?.home as any[]) || DEFAULT_HOME_SECTIONS;
  sections = [...sections].sort((a, b) => a.order - b.order);

  return (
    <div className="relative min-h-screen">
      <GlowBackground />
      <Navbar />
      <main>
        {sections.map(sec => {
          if (!sec.visible) return null;
          switch (sec.type) {
            case "Hero": return <Hero key={sec.id} />;
            case "Stats": return <Stats key={sec.id} />;
            case "Services": return <Services key={sec.id} />;
            case "WhyChooseUs": return <WhyChooseUs key={sec.id} />;
            case "Work": return <Work key={sec.id} />;
            case "Testimonials": return <Testimonials key={sec.id} />;
            case "BrandMarquee": return <BrandMarquee key={sec.id} />;
            case "ClosingCTA": return <ClosingCTA key={sec.id} />;
            case "TextImage": return <TextImageSection key={sec.id} payload={sec.payload} />;
            case "CustomCTA": return <CTASection key={sec.id} payload={sec.payload} />;
            default: return null;
          }
        })}
      </main>
      <Footer />
    </div>
  );
}
`;

code = code.replace(/function Index\(\) \{[\s\S]*\}\n?$/, renderLogic);

fs.writeFileSync('src/routes/index.tsx', code);
