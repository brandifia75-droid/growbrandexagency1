const fs = require('fs');
const env = fs.readFileSync('.env', 'utf8').split('\n').reduce((acc, line) => {
  const [key, ...value] = line.split('=');
  if (key) acc[key.trim()] = value.join('=').trim().replace(/['"]/g, '');
  return acc;
}, {});

async function check() {
  const res = await fetch(`${env.VITE_SUPABASE_URL}/rest/v1/?apikey=${env.VITE_SUPABASE_PUBLISHABLE_KEY}`);
  if (res.ok) {
    const json = await res.json();
    console.log(Object.keys(json.definitions));
  } else {
    console.log(res.status, await res.text());
  }
}
check();
