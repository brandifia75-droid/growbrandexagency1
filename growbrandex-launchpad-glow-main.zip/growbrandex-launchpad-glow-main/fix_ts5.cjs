const fs = require('fs');

function replace(file, search, replaceStr) {
  let code = fs.readFileSync(file, 'utf8');
  code = code.split(search).join(replaceStr);
  fs.writeFileSync(file, code);
}

replace('src/components/admin/SettingsForm.tsx', 'base64: base64Str,', 'base64: base64Str as string,');
replace('src/routes/admin/portfolio.tsx', 'base64: base64Str,', 'base64: base64Str as string,');
replace('src/routes/admin/images.tsx', '?.logo_url', '?.["logo_url"]');

