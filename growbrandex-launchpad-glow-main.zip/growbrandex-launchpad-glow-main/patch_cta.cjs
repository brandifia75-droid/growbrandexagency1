const fs = require('fs');
let ctaCode = fs.readFileSync('src/components/home/ClosingCTA.tsx', 'utf8');

if (!ctaCode.includes('ContactForm')) {
  ctaCode = ctaCode.replace('import { useSite, txt } from "@/lib/site-content";', 'import { useSite, txt } from "@/lib/site-content";\nimport { ContactForm } from "./ContactForm";');
  
  const oldButtons = `<div className="relative mt-9 flex flex-col justify-center gap-4 sm:flex-row">
            <Button variant="neon" size="xl" asChild>
              <a href={\`mailto:\${email}\`}>
                {button} <ArrowRight />
              </a>
            </Button>
            <Button variant="neonOutline" size="xl" asChild>
              <a href="#services">Explore Services</a>
            </Button>
          </div>`;
          
  const newForm = `<ContactForm />`;
  
  ctaCode = ctaCode.replace(oldButtons, newForm);
  fs.writeFileSync('src/components/home/ClosingCTA.tsx', ctaCode);
}
