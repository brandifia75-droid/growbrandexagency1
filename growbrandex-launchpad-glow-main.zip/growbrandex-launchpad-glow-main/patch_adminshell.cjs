const fs = require('fs');
let code = fs.readFileSync('src/components/admin/AdminShell.tsx', 'utf8');

if (!code.includes('/admin/submissions')) {
  const oldMenu = `  { name: "Global Navigation", to: "/admin/navigation", icon: Map },
  { name: "Homepage Sections", to: "/admin/sections", icon: LayoutDashboard },
  { name: "Portfolio", to: "/admin/portfolio", icon: Briefcase },
  { name: "Services", to: "/admin/services", icon: Sparkles },
  { name: "Why Choose Us", to: "/admin/why-choose-us", icon: CheckCircle },
  { name: "Testimonials", to: "/admin/testimonials", icon: MessageSquareQuote },
  { name: "Images", to: "/admin/images", icon: Image },
  { name: "Settings", to: "/admin/about", icon: Settings },
  { name: "Account", to: "/admin/account", icon: User },`;
  
  const newMenu = `  { name: "Global Navigation", to: "/admin/navigation", icon: Map },
  { name: "Homepage Sections", to: "/admin/sections", icon: LayoutDashboard },
  { name: "Portfolio", to: "/admin/portfolio", icon: Briefcase },
  { name: "Services", to: "/admin/services", icon: Sparkles },
  { name: "Why Choose Us", to: "/admin/why-choose-us", icon: CheckCircle },
  { name: "Testimonials", to: "/admin/testimonials", icon: MessageSquareQuote },
  { name: "Images", to: "/admin/images", icon: Image },
  { name: "Submissions", to: "/admin/submissions", icon: Inbox },
  { name: "Settings", to: "/admin/about", icon: Settings },
  { name: "Account", to: "/admin/account", icon: User },`;
  
  if (code.includes(oldMenu)) {
    code = code.replace(oldMenu, newMenu);
  } else {
    // maybe we can just insert it before Settings
    code = code.replace('{ name: "Settings",', '{ name: "Submissions", to: "/admin/submissions", icon: Inbox },\n  { name: "Settings",');
  }
  
  if (!code.includes('Inbox,')) {
    code = code.replace('import {', 'import { Inbox,');
  }
  
  fs.writeFileSync('src/components/admin/AdminShell.tsx', code);
}
