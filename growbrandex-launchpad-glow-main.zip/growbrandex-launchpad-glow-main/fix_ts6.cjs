const fs = require('fs');

function replace(file, search, replaceStr) {
  let code = fs.readFileSync(file, 'utf8');
  code = code.split(search).join(replaceStr);
  fs.writeFileSync(file, code);
}

replace('src/routes/admin/images.tsx', '(settings?.branding as Record<string, string>)', '(settings?.["branding"] as Record<string, string>)');

