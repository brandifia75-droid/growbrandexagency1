const fs = require('fs');
const env = fs.readFileSync('.env', 'utf8').split('\n').reduce((acc, line) => {
  const [key, ...value] = line.split('=');
  if (key) acc[key.trim()] = value.join('=').trim().replace(/['"]/g, '');
  return acc;
}, {});

async function check() {
  const res = await fetch(`${env.VITE_SUPABASE_URL}/rest/v1/rpc/has_role`, {
    method: 'POST',
    headers: { 'apikey': env.VITE_SUPABASE_PUBLISHABLE_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ _user_id: '00000000-0000-0000-0000-000000000000', _role: 'admin' })
  });
  console.log('rpc/has_role status:', res.status, await res.text());
}
check();
