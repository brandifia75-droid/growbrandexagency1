import { createFileRoute } from "@tanstack/react-router";
import { GlowBackground } from "@/components/home/GlowBackground";
import { Navbar } from "@/components/home/Navbar";
import { Hero } from "@/components/home/Hero";
import { Stats } from "@/components/home/Stats";
import { Services } from "@/components/home/Services";
import { WhyChooseUs } from "@/components/home/WhyChooseUs";
import { Work } from "@/components/home/Work";
import { Testimonials } from "@/components/home/Testimonials";
import { BrandMarquee } from "@/components/home/BrandMarquee";
import { ClosingCTA } from "@/components/home/ClosingCTA";
import { Footer } from "@/components/home/Footer";


import { useSite } from "@/lib/site-content";
import { TextImageSection, CTASection } from "@/components/sections/DynamicSection";

const DEFAULT_HOME_SECTIONS = [
  { id: "home-hero", type: "Hero", visible: true, order: 1, isCore: true },
  { id: "home-stats", type: "Stats", visible: true, order: 2, isCore: true },
  { id: "home-services", type: "Services", visible: true, order: 3, isCore: true },
  { id: "home-why-choose-us", type: "WhyChooseUs", visible: true, order: 4, isCore: true },
  { id: "home-work", type: "Work", visible: true, order: 5, isCore: true },
  { id: "home-testimonials", type: "Testimonials", visible: true, order: 6, isCore: true },
  { id: "home-brand-marquee", type: "BrandMarquee", visible: true, order: 7, isCore: true },
  { id: "home-cta", type: "ClosingCTA", visible: true, order: 8, isCore: true },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GrowBrandex | We Build Brands That Grow" },
      {
        name: "description",
        content:
          "GrowBrandex is a full-service digital growth agency: branding, web development, AI photoshoots, AI UGC ads and social media management.",
      },
      { property: "og:title", content: "GrowBrandex | We Build Brands That Grow" },
      {
        property: "og:description",
        content:
          "150+ projects delivered, 80+ happy clients, 4.9/5 average rating. Build and scale your brand online with GrowBrandex.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});


function Index() {
  const { settings } = useSite();
  let sections = (settings?.['page_sections']?.['home'] as any[]) || DEFAULT_HOME_SECTIONS;
  sections = [...sections].sort((a, b) => a.order - b.order);

  return (
    <div className="relative min-h-screen">
      <GlowBackground />
      <Navbar />
      <main>
        {sections.map(sec => {
          if (!sec.visible) return null;
          switch (sec.type) {
            case "Hero": return <Hero key={sec.id} />;
            case "Stats": return <Stats key={sec.id} />;
            case "Services": return <Services key={sec.id} />;
            case "WhyChooseUs": return <WhyChooseUs key={sec.id} />;
            case "Work": return <Work key={sec.id} />;
            case "Testimonials": return <Testimonials key={sec.id} />;
            case "BrandMarquee": return <BrandMarquee key={sec.id} />;
            case "ClosingCTA": return <ClosingCTA key={sec.id} />;
            case "TextImage": return <TextImageSection key={sec.id} payload={sec.payload} />;
            case "CustomCTA": return <CTASection key={sec.id} payload={sec.payload} />;
            default: return null;
          }
        })}
      </main>
      <Footer />
    </div>
  );
}
