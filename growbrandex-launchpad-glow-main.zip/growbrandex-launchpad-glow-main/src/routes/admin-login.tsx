import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Loader2, Lock, ShieldCheck } from "lucide-react";
import { GlowBackground } from "@/components/home/GlowBackground";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { checkAdmin } from "@/lib/admin.functions";
import logo from "@/assets/growbrandex-logo.png.asset.json";

const ADMIN_EMAIL = "admin@growbrandex.com";

export const Route = createFileRoute("/admin-login")({
  validateSearch: (search: Record<string, unknown>): { denied?: string } =>
    typeof search["denied"] === "string" ? { denied: search["denied"] } : {},

  head: () => ({
    meta: [
      { title: "Admin Login | GrowBrandex" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminLogin,
});

function AdminLogin() {
  const { denied } = Route.useSearch();
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(
    denied ? "This account does not have admin access." : null,
  );

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const raw = identifier.trim();
    const email = raw.includes("@") ? raw : raw.toLowerCase() === "admin" ? ADMIN_EMAIL : raw;

    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
    if (signInError) {
      setError("Invalid username or password.");
      setLoading(false);
      return;
    }

    const result = await checkAdmin().catch(() => null);
    if (!result?.isAdmin) {
      await supabase.auth.signOut();
      setError("This account does not have admin access.");
      setLoading(false);
      return;
    }

    navigate({ to: "/admin", replace: true });
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center bg-background px-5 py-16 text-foreground">
      <GlowBackground />
      <div className="relative w-full max-w-md">
        <Link to="/" className="mb-8 flex justify-center">
          <img src={logo.url} alt="GrowBrandex logo" className="h-9 w-auto" />
        </Link>
        <div className="rounded-2xl border border-border/60 bg-card/60 p-8 backdrop-blur-xl">
          <div className="flex items-center gap-2 text-primary">
            <ShieldCheck className="h-5 w-5" />
            <span className="text-xs font-semibold uppercase tracking-[0.2em]">Admin access</span>
          </div>
          <h1 className="mt-4 font-display text-2xl font-bold">Sign in to the Admin Panel</h1>
          <p className="mt-2 text-sm text-muted-foreground">Authorised administrators only.</p>

          <form onSubmit={onSubmit} className="mt-8 space-y-5">
            <div className="space-y-2">
              <Label htmlFor="identifier">Username or email</Label>
              <Input
                id="identifier"
                autoComplete="username"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="admin"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>

            {error ? (
              <p
                role="alert"
                className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive"
              >
                {error}
              </p>
            ) : null}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Signing in…
                </>
              ) : (
                <>
                  <Lock className="mr-2 h-4 w-4" /> Log in
                </>
              )}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
