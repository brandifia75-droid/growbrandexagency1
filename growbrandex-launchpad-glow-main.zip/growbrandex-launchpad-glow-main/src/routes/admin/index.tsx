import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle, Briefcase, MessageSquareQuote, Sparkles } from "lucide-react";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "Overview | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminOverview,
});

const cards = [
  { label: "Portfolio projects", value: "12", icon: Briefcase, to: "/admin/portfolio" },
  { label: "Services", value: "5", icon: Sparkles, to: "/admin/services" },
  { label: "Testimonials", value: "3", icon: MessageSquareQuote, to: "/admin/testimonials" },
  { label: "Why Choose Us", value: "6", icon: CheckCircle, to: "/admin/why-choose-us" },
] as const;

function AdminOverview() {
  const { user } = Route.useRouteContext();

  return (
    <div className="animate-fade-in space-y-6">
      <div className="rounded-2xl border border-border/60 bg-card/60 p-6 backdrop-blur-xl sm:p-8">
        <h2 className="font-display text-2xl font-bold">
          Welcome back<span className="text-primary">.</span>
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Signed in as <span className="text-foreground">{user?.email}</span>. Use the menu to jump
          to the part of the website you want to manage.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <Link
              key={c.label}
              to={c.to}
              className="group rounded-2xl border border-border/60 bg-card/60 p-5 backdrop-blur-xl transition-all hover:-translate-y-1 hover:border-primary/50 hover:glow-neon"
            >
              <Icon className="h-5 w-5 text-primary" />
              <p className="mt-4 font-display text-3xl font-bold">{c.value}</p>
              <p className="mt-1 text-sm text-muted-foreground">{c.label}</p>
            </Link>
          );
        })}
      </div>

      <div className="rounded-2xl border border-border/60 bg-card/60 p-6 backdrop-blur-xl">
        <h3 className="font-display text-lg font-bold">Next steps</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          The dashboard layout is ready. Content editing, project and service management, image
          uploads will be enabled section by section.
        </p>
      </div>
    </div>
  );
}
