import { createFileRoute } from "@tanstack/react-router";
import { SettingsForm, type SettingGroup } from "@/components/admin/SettingsForm";

const groups: SettingGroup[] = [
  {
    key: "about",
    title: "About page content",
    description: "Story, mission and section titles used on the About page.",
    fields: [
      { name: "eyebrow", label: "Eyebrow" },
      { name: "title", label: "Main heading" },
      { name: "story", label: "Our story", type: "textarea" },
      { name: "difference", label: "What makes us different", type: "textarea" },
      { name: "mission", label: "Our mission", type: "textarea" },
      { name: "timelineTitle", label: "Timeline section title" },
      { name: "skillsTitle", label: "Expertise section title" },
    ],
  },
];

export const Route = createFileRoute("/admin/about")({
  head: () => ({
    meta: [
      { title: "About | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: () => <SettingsForm groups={groups} />,
});
