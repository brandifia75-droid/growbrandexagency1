import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useSite, siteContentQuery } from "@/lib/site-content";
import { updateSetting } from "@/lib/settings.functions";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ArrowUp, ArrowDown, Save, Navigation } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/navigation")({
  head: () => ({
    meta: [
      { title: "Navigation | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminNavigation,
});

export const defaultNavigation = [
  { label: "Home", href: "/", route: true, visible: true },
  { label: "Services", href: "/services", route: true },
  { label: "Why Choose Us", href: "/#why-choose-us", route: false, visible: true },
  { label: "About", href: "/about", route: true },
  { label: "Work", href: "/#work", route: false },
  { label: "Portfolio", href: "/portfolio", route: true },
  { label: "Testimonials", href: "/#testimonials", route: false },
  { label: "Contact", href: "/#contact", route: false },
];

export type NavItem = {
  label: string;
  href: string;
  route: boolean;
  visible: boolean;
};

function AdminNavigation() {
  const { settings } = useSite();
  const queryClient = useQueryClient();

  const [items, setItems] = useState<NavItem[]>([]);

  useEffect(() => {
    // If we have settings saved, use them. Otherwise, initialize with defaults
    if (settings?.['navigation']?.['items']) {
      const savedItems = settings['navigation']['items'] as NavItem[];
      const mergedItems = [...savedItems];
      if (!mergedItems.find(i => i.href === "/")) {
         mergedItems.unshift({ label: "Home", href: "/", route: true, visible: true });
      }
      if (!mergedItems.find(i => i.href === "/#why-choose-us")) {
         const servicesIndex = mergedItems.findIndex(i => i.href === "/services");
         const insertIdx = servicesIndex !== -1 ? servicesIndex + 1 : 0;
         mergedItems.splice(insertIdx, 0, { label: "Why Choose Us", href: "/#why-choose-us", route: false, visible: true });
      }
      setItems(mergedItems);
    } else {
      setItems(defaultNavigation.map((item) => ({ ...item, visible: true })));
    }
  }, [settings?.['navigation']?.['items']]);

  const mutation = useMutation({
    mutationFn: (newItems: NavItem[]) =>
      updateSetting({
        data: {
          key: "navigation",
          value: { items: newItems },
        },
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
      toast.success("Navigation saved successfully");
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Failed to save navigation");
    },
  });

  const moveUp = (index: number) => {
    if (index === 0) return;
    const newItems = [...items];
    const temp = newItems[index - 1] as NavItem;
    newItems[index - 1] = newItems[index] as NavItem;
    newItems[index] = temp as NavItem;
    setItems(newItems);
  };

  const moveDown = (index: number) => {
    if (index === items.length - 1) return;
    const newItems = [...items];
    const temp = newItems[index + 1] as NavItem;
    newItems[index + 1] = newItems[index] as NavItem;
    newItems[index] = temp as NavItem;
    setItems(newItems);
  };

  const toggleVisibility = (index: number) => {
    const newItems = [...items];
    newItems[index] = { ...(newItems[index] as NavItem), visible: !(newItems[index] as NavItem).visible } as NavItem;
    setItems(newItems);
  };

  const handleSave = () => {
    mutation.mutate(items);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Navigation</h1>
          <p className="text-muted-foreground">Manage the links shown in the public header.</p>
        </div>
        <Button onClick={handleSave} disabled={mutation.isPending}>
          <Save className="mr-2 h-4 w-4" />
          {mutation.isPending ? "Saving..." : "Save Changes"}
        </Button>
      </div>

      <div className="rounded-xl border border-border/60 bg-card/40 p-6 backdrop-blur-xl">
        <div className="space-y-4">
          {items.map((item, index) => (
            <div
              key={item.href}
              className="flex items-center justify-between rounded-lg border border-border/70 bg-background/50 p-4 transition-all"
            >
              <div className="flex items-center gap-4">
                <Navigation className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.href}</p>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Switch
                    id={`visible-${index}`}
                    checked={item.visible}
                    onCheckedChange={() => toggleVisibility(index)}
                  />
                  <Label htmlFor={`visible-${index}`} className="text-sm">
                    {item.visible ? "Visible" : "Hidden"}
                  </Label>
                </div>

                <div className="flex items-center gap-1 border-l border-border/60 pl-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => moveUp(index)}
                    disabled={index === 0}
                    className="h-8 w-8"
                  >
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => moveDown(index)}
                    disabled={index === items.length - 1}
                    className="h-8 w-8"
                  >
                    <ArrowDown className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
