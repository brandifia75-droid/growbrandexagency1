import { createFileRoute } from "@tanstack/react-router";
import { useSite, siteContentQuery } from "@/lib/site-content";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { upsertWhyChooseUs, deleteWhyChooseUs } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { icons } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Edit2, Trash2, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/why-choose-us")({
  head: () => ({
    meta: [
      { title: "Why Choose Us | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminWhyChooseUs,
});

type WhyChooseUsItem = ReturnType<typeof useSite>["whyChooseUs"][0];

function AdminWhyChooseUs() {
  const { whyChooseUs } = useSite();
  const queryClient = useQueryClient();

  const [editItem, setEditItem] = useState<Partial<WhyChooseUsItem> | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const saveMutation = useMutation({
    mutationFn: (data: Partial<WhyChooseUsItem>) =>
      upsertWhyChooseUs({
        data: data as Required<Pick<WhyChooseUsItem, "title" | "description">> &
          Partial<WhyChooseUsItem>,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
      toast.success("Item saved successfully.");
      setEditItem(null);
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Failed to save item.");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteWhyChooseUs({ data: { id } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
      toast.success("Item deleted successfully.");
      setDeleteId(null);
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Failed to delete item.");
    },
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editItem) return;
    saveMutation.mutate(editItem);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Why Choose Us</h1>
          <p className="text-muted-foreground">Manage the reasons why clients should choose you.</p>
        </div>
        <Button
          onClick={() =>
            setEditItem({
              title: "",
              description: "",
              source: "CheckCircle",
              sort_order: (whyChooseUs.length + 1) * 10,
            })
          }
        >
          <Plus className="mr-2 h-4 w-4" /> Add Item
        </Button>
      </div>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[80px]">Icon</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Order</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {whyChooseUs.map((item) => {
              const IconComp =
                (icons as Record<string, any>)[item.source || "CheckCircle"] || CheckCircle;
              return (
                <TableRow key={item.id}>
                  <TableCell>
                    <IconComp className="h-5 w-5 text-neon" />
                  </TableCell>
                  <TableCell className="font-medium">{item.title}</TableCell>
                  <TableCell className="max-w-[300px] truncate">{item.description}</TableCell>
                  <TableCell>{item.sort_order}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" onClick={() => setEditItem(item)}>
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                        onClick={() => setDeleteId(item.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
            {whyChooseUs.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                  No items found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!editItem} onOpenChange={(open) => !open && setEditItem(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <form onSubmit={handleSave}>
            <DialogHeader>
              <DialogTitle>{editItem?.id ? "Edit Item" : "Add Item"}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={editItem?.title || ""}
                  onChange={(e) => setEditItem({ ...editItem!, title: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={editItem?.description || ""}
                  onChange={(e) => setEditItem({ ...editItem!, description: e.target.value })}
                  required
                  rows={4}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="source">Lucide Icon Name</Label>
                <Input
                  id="source"
                  value={editItem?.source || ""}
                  onChange={(e) => setEditItem({ ...editItem!, source: e.target.value })}
                  placeholder="e.g. CheckCircle, Star, Target"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="sort_order">Display Order</Label>
                <Input
                  id="sort_order"
                  type="number"
                  value={editItem?.sort_order || 0}
                  onChange={(e) =>
                    setEditItem({
                      ...editItem!,
                      sort_order: parseInt(e.target.value) || 0,
                    })
                  }
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditItem(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the item from your
              database.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteMutation.isPending}
              onClick={() => {
                if (deleteId) deleteMutation.mutate(deleteId);
              }}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
