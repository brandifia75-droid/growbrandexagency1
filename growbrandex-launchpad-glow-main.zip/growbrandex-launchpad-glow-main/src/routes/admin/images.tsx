import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listImages, uploadImage, deleteImage } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Upload, Copy, ExternalLink, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { useState, useRef } from "react";
import { useSite } from "@/lib/site-content";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/admin/images")({
  head: () => ({
    meta: [
      { title: "Images | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminImages,
});

function AdminImages() {
  const { projects, settings } = useSite();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [deletePath, setDeletePath] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const imagesQuery = useQuery({
    queryKey: ["admin-images"],
    queryFn: () => listImages(),
  });

  const deleteMutation = useMutation({
    mutationFn: (path: string) => deleteImage({ data: { path } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-images"] });
      toast.success("Image deleted successfully");
      setDeletePath(null);
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Failed to delete image");
    },
  });

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select a valid image file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image size must be less than 5MB");
      return;
    }

    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Str = (reader.result as string).split(",")[1];

        // simple sanitization for filename
        const safeName = file.name.replace(/[^a-zA-Z0-9.-]/g, "_");
        const path = `uploads/${Date.now()}-${safeName}`;

        await uploadImage({
          data: {
            path,
            base64: base64Str as string,
            contentType: file.type,
          },
        });

        queryClient.invalidateQueries({ queryKey: ["admin-images"] });
        toast.success("Image uploaded successfully");
        if (fileInputRef.current) fileInputRef.current.value = "";
      };
      reader.readAsDataURL(file);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to upload image");
    } finally {
      setUploading(false);
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    toast.success("URL copied to clipboard");
  };

  const handleDelete = (path: string) => {
    const url = `/api/public/img/${path}`;

    // Check if in use by projects
    const inUseProject = projects.find((p) => p.image_url === url);
    if (inUseProject) {
      toast.error(`Cannot delete: In use by project "${inUseProject.title}"`);
      return;
    }

    // Check if in use by settings (logo)
    const logoUrl = (settings?.["branding"] as Record<string, string>)?.["logo_url"];
    if (logoUrl === url) {
      toast.error("Cannot delete: In use as the site logo");
      return;
    }

    setDeletePath(path);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Images</h1>
          <p className="text-muted-foreground">Manage storage images for projects, logo, etc.</p>
        </div>
        <div>
          <input
            type="file"
            accept="image/*"
            className="hidden"
            ref={fileInputRef}
            onChange={handleUpload}
          />
          <Button onClick={() => fileInputRef.current?.click()} disabled={uploading}>
            {uploading ? (
              "Uploading..."
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" /> Upload Image
              </>
            )}
          </Button>
        </div>
      </div>

      {imagesQuery.isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading images...</div>
      ) : imagesQuery.isError ? (
        <div className="text-center py-12 text-destructive">Failed to load images</div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {imagesQuery.data?.map((img) => (
            <div
              key={img.id}
              className="group relative rounded-md border bg-card overflow-hidden flex flex-col"
            >
              <div className="aspect-square bg-muted/50 flex items-center justify-center p-2">
                <img
                  src={img.url}
                  alt={img.name}
                  className="max-w-full max-h-full object-contain"
                  loading="lazy"
                />
              </div>
              <div className="p-3 text-xs border-t">
                <p className="truncate font-medium" title={img.name}>
                  {img.name}
                </p>
                <p className="text-muted-foreground mt-1">{img.fullPath}</p>
              </div>

              <div className="absolute inset-0 bg-background/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => copyToClipboard(img.url)}
                  className="w-24"
                >
                  <Copy className="mr-2 h-3 w-3" /> Copy URL
                </Button>
                <Button variant="secondary" size="sm" asChild className="w-24">
                  <a href={img.url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="mr-2 h-3 w-3" /> View
                  </a>
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => handleDelete(img.fullPath)}
                  className="w-24"
                >
                  <Trash2 className="mr-2 h-3 w-3" /> Delete
                </Button>
              </div>
            </div>
          ))}
          {(!imagesQuery.data || imagesQuery.data.length === 0) && (
            <div className="col-span-full text-center py-12 text-muted-foreground border rounded-md">
              <ImageIcon className="mx-auto h-8 w-8 mb-3 opacity-20" />
              <p>No images found in storage</p>
            </div>
          )}
        </div>
      )}

      <AlertDialog open={!!deletePath} onOpenChange={(open) => !open && setDeletePath(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Image</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure? This will permanently delete the image from storage. Ensure no other
              components or pages are actively using it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteMutation.isPending}
              onClick={() => deletePath && deleteMutation.mutate(deletePath)}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
