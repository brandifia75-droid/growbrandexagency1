import { createFileRoute } from "@tanstack/react-router";
import { useSite, siteContentQuery } from "@/lib/site-content";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { upsertTestimonial, deleteTestimonial } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/testimonials")({
  head: () => ({
    meta: [
      { title: "Testimonials | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminTestimonials,
});

type Testimonial = ReturnType<typeof useSite>["testimonials"][0];

function AdminTestimonials() {
  const { testimonials } = useSite();
  const queryClient = useQueryClient();

  const [editTestimonial, setEditTestimonial] = useState<Partial<Testimonial> | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const saveMutation = useMutation({
    mutationFn: (data: Partial<Testimonial>) =>
      upsertTestimonial({
        data: data as Required<Pick<Testimonial, "author" | "quote">> & Partial<Testimonial>,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
      toast.success("Testimonial saved successfully.");
      setEditTestimonial(null);
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Failed to save testimonial.");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteTestimonial({ data: { id } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
      toast.success("Testimonial deleted successfully.");
      setDeleteId(null);
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Failed to delete testimonial.");
    },
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTestimonial) return;
    saveMutation.mutate(editTestimonial);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Testimonials</h1>
          <p className="text-muted-foreground">Manage your client reviews and feedback.</p>
        </div>
        <Button
          onClick={() =>
            setEditTestimonial({
              author: "",
              quote: "",
              role: "",
              sort_order: (testimonials.length + 1) * 10,
            })
          }
        >
          <Plus className="mr-2 h-4 w-4" /> Add Testimonial
        </Button>
      </div>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Client Name</TableHead>
              <TableHead>Role/Company</TableHead>
              <TableHead>Review</TableHead>
              <TableHead>Order</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {testimonials.map((testimonial) => (
              <TableRow key={testimonial.id}>
                <TableCell className="font-medium">{testimonial.author}</TableCell>
                <TableCell>{testimonial.role}</TableCell>
                <TableCell className="max-w-[300px] truncate">{testimonial.quote}</TableCell>
                <TableCell>{testimonial.sort_order}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setEditTestimonial(testimonial)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive"
                      onClick={() => setDeleteId(testimonial.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {testimonials.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                  No testimonials found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!editTestimonial} onOpenChange={(open) => !open && setEditTestimonial(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <form onSubmit={handleSave}>
            <DialogHeader>
              <DialogTitle>
                {editTestimonial?.id ? "Edit Testimonial" : "Add Testimonial"}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="author">Client Name</Label>
                <Input
                  id="author"
                  value={editTestimonial?.author || ""}
                  onChange={(e) =>
                    setEditTestimonial({ ...editTestimonial!, author: e.target.value })
                  }
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="role">Role / Company</Label>
                <Input
                  id="role"
                  value={editTestimonial?.role || ""}
                  onChange={(e) =>
                    setEditTestimonial({ ...editTestimonial!, role: e.target.value })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="quote">Review Text</Label>
                <Textarea
                  id="quote"
                  value={editTestimonial?.quote || ""}
                  onChange={(e) =>
                    setEditTestimonial({ ...editTestimonial!, quote: e.target.value })
                  }
                  required
                  rows={4}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="sort_order">Display Order</Label>
                <Input
                  id="sort_order"
                  type="number"
                  value={editTestimonial?.sort_order || 0}
                  onChange={(e) =>
                    setEditTestimonial({
                      ...editTestimonial!,
                      sort_order: parseInt(e.target.value) || 0,
                    })
                  }
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditTestimonial(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the testimonial from your
              database.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteMutation.isPending}
              onClick={() => {
                if (deleteId) deleteMutation.mutate(deleteId);
              }}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
