import { createFileRoute } from "@tanstack/react-router";
import { AdminWebsiteSections } from "@/components/admin/WebsiteSections";

export const Route = createFileRoute("/admin/sections")({
  head: () => ({
    meta: [{ title: "Website Sections | GrowBrandex Admin" }],
  }),
  component: AdminWebsiteSections,
});
