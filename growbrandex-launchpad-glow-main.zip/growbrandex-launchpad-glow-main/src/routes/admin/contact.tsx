import { createFileRoute } from "@tanstack/react-router";
import { SettingsForm, type SettingGroup } from "@/components/admin/SettingsForm";

const groups: SettingGroup[] = [
  {
    key: "contact",
    title: "Contact details & social links",
    description: "Used in the footer and contact call to action across the website.",
    fields: [
      { name: "email", label: "Email address" },
      { name: "whatsapp", label: "WhatsApp / phone" },
      { name: "instagram", label: "Instagram URL" },
      { name: "linkedin", label: "LinkedIn URL" },
      { name: "twitter", label: "X (Twitter) URL" },
      { name: "facebook", label: "Facebook URL" },
      { name: "youtube", label: "YouTube URL", help: "Leave empty to hide this icon." },
    ],
  },
  {
    key: "contact_page",
    title: "Contact section copy",
    fields: [
      { name: "eyebrow", label: "Eyebrow" },
      { name: "title", label: "Heading" },
      { name: "subtitle", label: "Subtitle", type: "textarea" },
      { name: "address", label: "Address / location" },
      { name: "hours", label: "Working hours" },
    ],
  },
];

export const Route = createFileRoute("/admin/contact")({
  head: () => ({
    meta: [
      { title: "Contact | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: () => <SettingsForm groups={groups} />,
});
