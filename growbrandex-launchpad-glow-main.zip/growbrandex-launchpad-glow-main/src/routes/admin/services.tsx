import { createFileRoute } from "@tanstack/react-router";
import { useSite, siteContentQuery } from "@/lib/site-content";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { upsertService, deleteService } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { icons } from "lucide-react";

export const Route = createFileRoute("/admin/services")({
  head: () => ({
    meta: [
      { title: "Services | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminServices,
});

type Service = ReturnType<typeof useSite>["services"][0];

function AdminServices() {
  const { services } = useSite();
  const queryClient = useQueryClient();

  const [editService, setEditService] = useState<Partial<Service> | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const saveMutation = useMutation({
    mutationFn: (data: Partial<Service>) =>
      upsertService({ data: data as Required<Pick<Service, "title">> & Partial<Service> }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
      toast.success("Service saved successfully.");
      setEditService(null);
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Failed to save service.");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteService({ data: { id } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
      toast.success("Service deleted successfully.");
      setDeleteId(null);
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Failed to delete service.");
    },
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editService) return;
    saveMutation.mutate(editService);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Services</h1>
          <p className="text-muted-foreground">Manage your services and display order.</p>
        </div>
        <Button
          onClick={() =>
            setEditService({
              title: "",
              short_description: "",
              long_description: "",
              icon: "Zap",
              sort_order: (services.length + 1) * 10,
            })
          }
        >
          <Plus className="mr-2 h-4 w-4" /> Add Service
        </Button>
      </div>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[80px]">Icon</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Short Description</TableHead>
              <TableHead>Order</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {services.map((service) => {
              const IconComp = (icons as Record<string, any>)[service.icon || "Zap"] || icons.Zap;
              return (
                <TableRow key={service.id}>
                  <TableCell>
                    <IconComp className="h-6 w-6 text-neon" />
                  </TableCell>
                  <TableCell className="font-medium">{service.title}</TableCell>
                  <TableCell className="max-w-[200px] truncate">
                    {service.short_description}
                  </TableCell>
                  <TableCell>{service.sort_order}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" onClick={() => setEditService(service)}>
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                        onClick={() => setDeleteId(service.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
            {services.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                  No services found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!editService} onOpenChange={(open) => !open && setEditService(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <form onSubmit={handleSave}>
            <DialogHeader>
              <DialogTitle>{editService?.id ? "Edit Service" : "Add Service"}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={editService?.title || ""}
                  onChange={(e) => setEditService({ ...editService!, title: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="short_description">Short Description (for Home)</Label>
                <Input
                  id="short_description"
                  value={editService?.short_description || ""}
                  onChange={(e) =>
                    setEditService({ ...editService!, short_description: e.target.value })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="long_description">Long Description (for Services Page)</Label>
                <Textarea
                  id="long_description"
                  value={editService?.long_description || ""}
                  onChange={(e) =>
                    setEditService({ ...editService!, long_description: e.target.value })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="icon">Lucide Icon Name</Label>
                <Input
                  id="icon"
                  value={editService?.icon || ""}
                  onChange={(e) => setEditService({ ...editService!, icon: e.target.value })}
                  placeholder="e.g. Brush, Code2, Camera"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="sort_order">Display Order</Label>
                <Input
                  id="sort_order"
                  type="number"
                  value={editService?.sort_order || 0}
                  onChange={(e) =>
                    setEditService({ ...editService!, sort_order: parseInt(e.target.value) || 0 })
                  }
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditService(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the service from your
              database.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteMutation.isPending}
              onClick={() => {
                if (deleteId) deleteMutation.mutate(deleteId);
              }}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
