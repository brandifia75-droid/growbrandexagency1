import { createFileRoute } from "@tanstack/react-router";
import { SettingsForm, type SettingGroup } from "@/components/admin/SettingsForm";

const groups: SettingGroup[] = [
  {
    key: "branding",
    title: "Branding",
    description: "Site logo and name used across the website.",
    fields: [
      { name: "site_name", label: "Site Name" },
      { name: "logo_url", label: "Logo Image", type: "image" },
    ],
  },
  {
    key: "home",
    title: "Hero section",
    description: "The first thing visitors see on the homepage.",
    fields: [
      { name: "heroEyebrow", label: "Eyebrow" },
      { name: "heroTitle", label: "Main heading" },
      { name: "heroHighlight", label: "Highlighted heading word(s)" },
      { name: "heroSubtitle", label: "Supporting line", type: "textarea" },
      { name: "ctaPrimary", label: "Primary button text" },
      { name: "ctaSecondary", label: "Secondary button text" },
    ],
  },
  {
    key: "stats",
    title: "Statistics",
    description: "Animated counters shown under the hero.",
    fields: [
      { name: "projects", label: "Projects delivered", type: "number" },
      { name: "clients", label: "Happy clients", type: "number" },
      { name: "services", label: "Services offered", type: "number" },
      { name: "rating", label: "Average rating", type: "number" },
    ],
  },
  {
    key: "home",
    title: "Section headings",
    description: "Headings for the stats, services, work, testimonials and brands sections.",
    fields: [
      { name: "statsTitle", label: "Stats title" },
      { name: "servicesEyebrow", label: "Services eyebrow" },
      { name: "servicesTitle", label: "Services title" },
      { name: "servicesSubtitle", label: "Services subtitle", type: "textarea" },
      { name: "workEyebrow", label: "Work eyebrow" },
      { name: "workTitle", label: "Work title" },
      { name: "workSubtitle", label: "Work subtitle", type: "textarea" },
      { name: "testimonialsEyebrow", label: "Testimonials eyebrow" },
      { name: "testimonialsTitle", label: "Testimonials title" },
      { name: "brandsTitle", label: "Brands row title" },
    ],
  },
  {
    key: "home",
    title: "Closing call to action",
    fields: [
      { name: "ctaTitle", label: "CTA heading" },
      { name: "ctaSubtitle", label: "CTA text", type: "textarea" },
      { name: "ctaButton", label: "CTA button text" },
    ],
  },
];

export const Route = createFileRoute("/admin/home")({
  head: () => ({
    meta: [{ title: "Home | GrowBrandex Admin" }, { name: "robots", content: "noindex, nofollow" }],
  }),
  component: () => <SettingsForm groups={groups} />,
});
