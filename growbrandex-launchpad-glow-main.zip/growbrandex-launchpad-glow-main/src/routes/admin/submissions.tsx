import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getSubmissions, markSubmissionRead, deleteSubmission } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { format } from "date-fns";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Eye, Trash2, Mail, MailOpen } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/admin/submissions")({
  head: () => ({
    meta: [
      { title: "Contact Submissions | GrowBrandex Admin" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminSubmissions,
});

function AdminSubmissions() {
  const queryClient = useQueryClient();
  const [selectedSub, setSelectedSub] = useState<any>(null);

  const { data: submissions = [], isLoading } = useQuery({
    queryKey: ["admin-submissions"],
    queryFn: () => getSubmissions(),
  });

  const markReadMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) => markSubmissionRead({ data: { id, status } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-submissions"] });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteSubmission({ data: { id } }),
    onSuccess: () => {
      toast.success("Submission deleted");
      setSelectedSub(null);
      queryClient.invalidateQueries({ queryKey: ["admin-submissions"] });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const handleOpen = (sub: any) => {
    setSelectedSub(sub);
    if (sub.status === "unread") {
      markReadMutation.mutate({ id: sub.id, status: "read" });
    }
  };

  const handleToggleStatus = (sub: any, e: React.MouseEvent) => {
    e.stopPropagation();
    markReadMutation.mutate({ 
      id: sub.id, 
      status: sub.status === "read" ? "unread" : "read" 
    });
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this submission?")) {
      deleteMutation.mutate(id);
    }
  };

  if (isLoading) {
    return <div className="p-8 text-center text-muted-foreground">Loading submissions...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl font-bold">Contact Submissions</h1>
      </div>

      <div className="rounded-xl border border-border/50 bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Service</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {submissions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                  No submissions found.
                </TableCell>
              </TableRow>
            ) : (
              submissions.map((sub: any) => (
                <TableRow 
                  key={sub.id} 
                  className={`cursor-pointer ${sub.status === 'unread' ? 'bg-muted/30 font-medium' : ''}`}
                  onClick={() => handleOpen(sub)}
                >
                  <TableCell>
                    {sub.status === 'unread' ? (
                      <Badge variant="default" className="bg-neon text-black">New</Badge>
                    ) : (
                      <Badge variant="outline" className="text-muted-foreground">Read</Badge>
                    )}
                  </TableCell>
                  <TableCell>{format(new Date(sub.created_at), "MMM d, yyyy")}</TableCell>
                  <TableCell>{sub.name}</TableCell>
                  <TableCell>{sub.service}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={(e) => handleToggleStatus(sub, e)}
                      title={sub.status === 'read' ? 'Mark as unread' : 'Mark as read'}
                    >
                      {sub.status === 'read' ? <Mail className="h-4 w-4" /> : <MailOpen className="h-4 w-4" />}
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                      onClick={(e) => handleDelete(sub.id, e)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!selectedSub} onOpenChange={(open) => !open && setSelectedSub(null)}>
        <DialogContent className="max-w-2xl border-neon/20">
          <DialogHeader>
            <DialogTitle>Inquiry Details</DialogTitle>
            <DialogDescription>
              Received on {selectedSub && format(new Date(selectedSub.created_at), "PPP 'at' p")}
            </DialogDescription>
          </DialogHeader>
          
          {selectedSub && (
            <div className="space-y-6 mt-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground mb-1">Name</p>
                  <p className="font-medium">{selectedSub.name}</p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Email</p>
                  <p className="font-medium">
                    <a href={`mailto:${selectedSub.email}`} className="text-neon hover:underline">
                      {selectedSub.email}
                    </a>
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Contact / Phone</p>
                  <p className="font-medium">{selectedSub.phone}</p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Service Needed</p>
                  <Badge variant="outline" className="border-neon/50 text-neon">
                    {selectedSub.service}
                  </Badge>
                </div>
              </div>
              
              <div className="pt-4 border-t border-border/50">
                <p className="text-muted-foreground mb-2 text-sm">Message</p>
                <div className="bg-muted/30 p-4 rounded-lg whitespace-pre-wrap text-sm leading-relaxed">
                  {selectedSub.message}
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <Button variant="outline" onClick={() => setSelectedSub(null)}>
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
