import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { X } from "lucide-react";
import { GlowBackground } from "@/components/home/GlowBackground";
import { Navbar } from "@/components/home/Navbar";
import { Footer } from "@/components/home/Footer";
import { Reveal } from "@/components/home/Reveal";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useSite } from "@/lib/site-content";

const categories = [
  "All",
  "Graphic Designing",
  "Web Development",
  "AI Photoshoot",
  "AI UGC Ads",
  "Social Media Management",
] as const;

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "Portfolio | GrowBrandex Case Studies & Client Work" },
      {
        name: "description",
        content:
          "Browse GrowBrandex projects across graphic design, web development, AI photoshoots, AI UGC ads and social media management.",
      },
      { property: "og:title", content: "Portfolio | GrowBrandex Case Studies & Client Work" },
      {
        property: "og:description",
        content:
          "Branding, websites, AI photoshoots, UGC ads and social media work delivered for 80+ clients.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PortfolioPage,
});

function PortfolioPage() {
  const { projects } = useSite();
  const [active, setActive] = useState<string>("All");
  const [openId, setOpenId] = useState<string | null>(null);

  const filtered = useMemo(
    () => (active === "All" ? projects : projects.filter((p) => p.category === active)),
    [active, projects],
  );
  const openProject = projects.find((p) => p.id === openId) ?? null;

  useEffect(() => {
    if (!openProject) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpenId(null);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [openProject]);

  return (
    <div className="relative min-h-screen">
      <GlowBackground />
      <Navbar />

      <main className="px-5 pb-24 pt-32 sm:px-8 sm:pt-40">
        <div className="mx-auto max-w-7xl">
          <Reveal className="text-center">
            <p className="text-xs uppercase tracking-[0.3em] text-neon">Our portfolio</p>
            <h1 className="mt-4 font-display text-4xl font-bold leading-[1.05] sm:text-6xl">
              Work that <span className="text-neon text-glow">grows brands</span>
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-muted-foreground">
              A selection of projects across all five of our services. Filter by what you need —
              then start something similar.
            </p>
          </Reveal>

          <Reveal className="mt-12" delay={100}>
            <div
              role="tablist"
              aria-label="Filter projects by service"
              className="flex flex-wrap justify-center gap-2 sm:gap-3"
            >
              {categories.map((c) => (
                <button
                  key={c}
                  role="tab"
                  aria-selected={active === c}
                  onClick={() => setActive(c)}
                  className={cn(
                    "rounded-full border px-4 py-2 text-sm font-medium transition-all duration-500 sm:px-5",
                    active === c
                      ? "border-neon/70 bg-neon/15 text-neon shadow-[0_0_28px_-8px_var(--neon)]"
                      : "border-border/70 text-muted-foreground hover:border-neon/40 hover:text-foreground",
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
          </Reveal>

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p, i) => (
              <Reveal key={`${active}-${p.id}`} delay={i * 70}>
                <button
                  type="button"
                  onClick={() => setOpenId(p.id)}
                  aria-label={`View ${p.title} project details`}
                  className="group block w-full overflow-hidden rounded-2xl border border-border/70 bg-card/40 text-left transition-all duration-500 hover:-translate-y-1.5 hover:border-neon/50 hover:shadow-[0_24px_60px_-24px_var(--neon)]"
                >
                  <div className="overflow-hidden">
                    <img
                      src={p.image_url}
                      alt={`${p.title} — ${p.category} project by GrowBrandex`}
                      width={1024}
                      height={768}
                      loading="lazy"
                      className="aspect-[4/3] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                    />
                  </div>
                  <div className="p-5">
                    <p className="text-xs uppercase tracking-[0.2em] text-neon">{p.category}</p>
                    <h2 className="mt-2 font-display text-lg font-semibold">{p.title}</h2>
                    <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                      {p.description}
                    </p>
                  </div>
                </button>
              </Reveal>
            ))}
          </div>
        </div>
      </main>

      {openProject && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`${openProject.title} project details`}
          onClick={() => setOpenId(null)}
          className="animate-fade-in fixed inset-0 z-[100] flex items-center justify-center bg-background/85 p-4 backdrop-blur-xl sm:p-8"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="animate-scale-in relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-neon/30 bg-card/90 shadow-[0_40px_120px_-40px_var(--neon)]"
          >
            <button
              type="button"
              onClick={() => setOpenId(null)}
              aria-label="Close project details"
              className="absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full border border-border/70 bg-background/80 text-foreground transition-colors hover:border-neon/60 hover:text-neon"
            >
              <X size={17} />
            </button>
            <img
              src={openProject.image_url}
              alt={`${openProject.title} — larger preview`}
              width={1024}
              height={768}
              className="aspect-[4/3] w-full object-cover"
            />
            <div className="p-6 sm:p-8">
              <p className="text-xs uppercase tracking-[0.2em] text-neon">{openProject.category}</p>
              <h3 className="mt-2 font-display text-2xl font-bold sm:text-3xl">
                {openProject.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">
                {openProject.description}
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <Button variant="neon" size="lg" asChild>
                  <Link to="/" hash="contact" onClick={() => setOpenId(null)}>
                    Start a Similar Project
                  </Link>
                </Button>
                <Button variant="neonOutline" size="lg" onClick={() => setOpenId(null)}>
                  Keep Browsing
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}
