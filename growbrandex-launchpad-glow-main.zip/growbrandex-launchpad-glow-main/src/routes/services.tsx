import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, icons } from "lucide-react";
import { GlowBackground } from "@/components/home/GlowBackground";
import { Navbar } from "@/components/home/Navbar";
import { Footer } from "@/components/home/Footer";
import { Reveal } from "@/components/home/Reveal";
import { Button } from "@/components/ui/button";
import { useSite } from "@/lib/site-content";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services | GrowBrandex — Five Ways We Build Brands That Grow" },
      {
        name: "description",
        content:
          "Explore GrowBrandex's core services: graphic design, web development, AI photoshoot, AI UGC ads, and social media management.",
      },
      {
        property: "og:title",
        content: "Services | GrowBrandex — Five Ways We Build Brands That Grow",
      },
      {
        property: "og:description",
        content:
          "Explore GrowBrandex's core services: graphic design, web development, AI photoshoot, AI UGC ads, and social media management.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const { services } = useSite();
  return (
    <div className="relative min-h-screen">
      <GlowBackground />
      <Navbar />

      <main className="px-5 pb-24 pt-32 sm:px-8 sm:pt-40">
        <div className="mx-auto max-w-7xl">
          {/* Hero */}
          <Reveal className="text-center">
            <p className="text-xs uppercase tracking-[0.3em] text-neon">What we do</p>
            <h1 className="mt-4 font-display text-4xl font-bold leading-[1.05] sm:text-6xl">
              Our services. <span className="text-neon text-glow">One growth engine.</span>
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground">
              Everything your brand needs to look premium, perform online, and scale faster — all
              under one roof.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button variant="neon" size="xl" asChild>
                <a href="/#contact">Start a Project</a>
              </Button>
              <Button variant="neonOutline" size="xl" asChild>
                <Link to="/portfolio">View Our Work</Link>
              </Button>
            </div>
          </Reveal>

          {/* Services Grid */}
          <section className="mt-20 sm:mt-28">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {services.map((service, index) => {
                const IconComp = (icons as Record<string, any>)[service.icon || "Zap"] || icons.Zap;
                return (
                  <Reveal key={service.id} delay={index * 110}>
                    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-border/70 bg-card/45 p-7 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1.5 hover:border-neon/50 hover:shadow-[0_0_30px_-12px_var(--neon)]">
                      <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-neon/35 bg-neon/10 text-neon transition-colors group-hover:bg-neon/20">
                        <IconComp size={22} />
                      </span>
                      <h3 className="mt-6 font-display text-xl font-semibold">{service.title}</h3>
                      <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                        {service.long_description || service.short_description}
                      </p>
                      <div className="mt-6 flex items-center justify-between gap-4">
                        <Button
                          variant="neonOutline"
                          size="sm"
                          className="rounded-full px-5"
                          asChild
                        >
                          <a href="/#contact">Get a Quote</a>
                        </Button>
                        <ArrowRight
                          size={18}
                          className="text-muted-foreground transition-all duration-300 group-hover:translate-x-1 group-hover:text-neon"
                        />
                      </div>
                    </article>
                  </Reveal>
                );
              })}
            </div>
          </section>

          {/* Why bundle */}
          <section className="mt-20 sm:mt-28">
            <div className="rounded-3xl border border-border/70 bg-card/40 p-8 sm:p-12 lg:p-16">
              <div className="mx-auto max-w-3xl text-center">
                <Reveal>
                  <p className="text-xs uppercase tracking-[0.3em] text-neon">Why us</p>
                  <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl">
                    One team for your entire brand <span className="text-neon">growth system</span>
                  </h2>
                </Reveal>
                <Reveal delay={120}>
                  <p className="mt-5 text-sm leading-relaxed text-muted-foreground sm:text-base">
                    Instead of juggling multiple different freelancers, you get a single partner
                    that handles design, development, and AI-powered content — so you can focus on
                    running your business while we grow your online presence.
                  </p>
                </Reveal>
                <Reveal delay={200}>
                  <div className="mt-8 flex flex-wrap justify-center gap-3">
                    {services.map((s) => {
                      const IconComp = (icons as Record<string, any>)[s.icon || "Zap"] || icons.Zap;
                      return (
                        <span
                          key={s.id}
                          className="inline-flex items-center gap-2 rounded-full border border-neon/30 bg-neon/10 px-4 py-2 text-sm text-neon"
                        >
                          <IconComp size={14} />
                          {s.title}
                        </span>
                      );
                    })}
                  </div>
                </Reveal>
              </div>
            </div>
          </section>

          {/* Closing CTA */}
          <Reveal className="mt-20 text-center sm:mt-28" delay={80}>
            <h2 className="font-display text-3xl font-bold sm:text-4xl">
              Ready to build your <span className="text-neon text-glow">brand system?</span>
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-sm text-muted-foreground sm:text-base">
              Tell us what you need. We'll recommend the right mix of services and send you a custom
              quote.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button variant="neon" size="xl" asChild>
                <a href="/#contact">Start a Project</a>
              </Button>
              <Button variant="neonOutline" size="xl" asChild>
                <Link to="/about">About Us</Link>
              </Button>
            </div>
          </Reveal>
        </div>
      </main>

      <Footer />
    </div>
  );
}
