import React from 'react';
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Brush, Code2, Camera, Clapperboard, Share2 } from "lucide-react";
import { GlowBackground } from "@/components/home/GlowBackground";
import { Navbar } from "@/components/home/Navbar";
import { Footer } from "@/components/home/Footer";
import { Reveal } from "@/components/home/Reveal";
import { Button } from "@/components/ui/button";
import { useReveal } from "@/hooks/use-reveal";
import { useSite, txt } from "@/lib/site-content";

const milestones = [
  {
    year: "Chapter 01",
    title: "Founded as a small design team",
    body: "We started by helping local business owners look more professional online.",
  },
  {
    year: "Chapter 02",
    title: "Added web development services",
    body: "Clients needed sites that matched their new identity — so we built them.",
  },
  {
    year: "Chapter 03",
    title: "Introduced AI-powered content production",
    body: "Studio-quality product imagery and creative, produced faster and for less.",
  },
  {
    year: "Chapter 04",
    title: "Expanded into full social media management",
    body: "From one-off content to owning the full publishing and community engine.",
  },
  {
    year: "Chapter 05",
    title: "Became a 5-service full digital agency",
    body: "One team handling creative, technical and AI-driven growth end to end.",
  },
];

const skills = [
  { label: "Graphic Designing", value: 96, Icon: Brush },
  { label: "Web Development", value: 92, Icon: Code2 },
  { label: "AI Photoshoot", value: 89, Icon: Camera },
  { label: "AI UGC Ads", value: 87, Icon: Clapperboard },
  { label: "Social Media Management", value: 94, Icon: Share2 },
];

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About GrowBrandex | Our Story, Mission & Expertise" },
      {
        name: "description",
        content:
          "How GrowBrandex grew from a small design team into a five-service digital growth agency building complete brand growth systems.",
      },
      { property: "og:title", content: "About GrowBrandex | Our Story, Mission & Expertise" },
      {
        property: "og:description",
        content:
          "Our story, milestones and the five service areas we use to build brands that grow.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

function SkillMeter({
  label,
  value,
  Icon,
  delay,
}: {
  label: string;
  value: number;
  Icon: typeof Brush;
  delay: number;
}) {
  const { ref, visible } = useReveal<HTMLDivElement>(0.4);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    if (!visible) return;
    const t = setTimeout(() => setWidth(value), delay);
    return () => clearTimeout(t);
  }, [visible, value, delay]);

  return (
    <div ref={ref} className="rounded-2xl border border-border/70 bg-card/40 p-5 sm:p-6">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-neon/40 bg-neon/10 text-neon">
            <Icon size={18} />
          </span>
          <p className="font-display text-base font-semibold sm:text-lg">{label}</p>
        </div>
        <p className="font-display text-sm font-semibold text-neon tabular-nums">{width}%</p>
      </div>
      <div className="mt-5 h-2 w-full overflow-hidden rounded-full bg-secondary/60">
        <div
          className="h-full rounded-full bg-gradient-to-r from-neon-soft to-neon shadow-[0_0_20px_-2px_var(--neon)] transition-[width] duration-[1600ms] ease-out"
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  );
}


import { TextImageSection, CTASection } from "@/components/sections/DynamicSection";

const DEFAULT_ABOUT_SECTIONS = [
  { id: "about-hero", type: "AboutHero", visible: true, order: 1, isCore: true },
  { id: "about-story", type: "AboutStory", visible: true, order: 2, isCore: true },
  { id: "about-timeline", type: "AboutTimeline", visible: true, order: 3, isCore: true },
  { id: "about-skills", type: "AboutSkills", visible: true, order: 4, isCore: true },
  { id: "about-cta", type: "AboutCTA", visible: true, order: 5, isCore: true }
];

function AboutPage() {
  const { settings } = useSite();
  const eyebrow = txt(settings, "about", "eyebrow", "About us");
  const title = txt(settings, "about", "title", "We build brands that grow");
  const story = txt(
    settings,
    "about",
    "story",
    "We began by giving local business owners a more professional presence online — logos, identities and the small details that make a business look established. Over time we expanded into a full-service digital agency covering design, development and AI-powered content, because our clients kept asking us to handle more of their growth in one place.",
  );
  const difference = txt(
    settings,
    "about",
    "difference",
    "What makes us different is that we don't just deliver a design or a video. We build a complete brand growth system — combining creative, technical and AI-driven content — so business owners can focus on running their business while we handle their online presence.",
  );
  const mission = txt(
    settings,
    "about",
    "mission",
    "To help business owners grow real, recognizable brands — without needing five different freelancers.",
  );
  const timelineTitle = txt(settings, "about", "timelineTitle", "How we grew");
  const skillsTitle = txt(settings, "about", "skillsTitle", "Where we're strongest");

  // Highlight logic for the main title: last word highlighted
  const words = title.split(" ");
  const titleHighlight = words.length > 1 ? words.pop() : "";
  const titleNormal = words.join(" ");

  // Highlight logic for timeline Title: last word highlighted
  const tWords = timelineTitle.split(" ");
  const tHighlight = tWords.length > 1 ? tWords.pop() : "";
  const tNormal = tWords.join(" ");

  // Highlight logic for skills Title: last word highlighted
  const sWords = skillsTitle.split(" ");
  const sHighlight = sWords.length > 1 ? sWords.pop() : "";
  const sNormal = sWords.join(" ");

  
  let sections = (settings?.['page_sections']?.['about'] as any[]) || DEFAULT_ABOUT_SECTIONS;
  sections = [...sections].sort((a, b) => a.order - b.order);

  return (
    <div className="relative min-h-screen">
      <GlowBackground />
      <Navbar />
      <main className="px-5 pb-24 pt-32 sm:px-8 sm:pt-40">
        <div className="mx-auto max-w-7xl">
          {sections.map(sec => {
            if (!sec.visible) return null;
            switch (sec.type) {
              case "AboutHero": return <React.Fragment key={sec.id}><Reveal className="text-center">
            <p className="text-xs uppercase tracking-[0.3em] text-neon">{eyebrow}</p>
            <h1 className="mt-4 font-display text-4xl font-bold leading-[1.05] sm:text-6xl">
              {titleNormal}{" "}
              {titleHighlight && <span className="text-neon text-glow">{titleHighlight}</span>}
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground">
              GrowBrandex started as a small team helping local business owners look more
              professional online. Today we are a full-service digital growth agency.
            </p>
          </Reveal></React.Fragment>;
              case "AboutStory": return <React.Fragment key={sec.id}><section className="mt-20 grid gap-6 lg:grid-cols-3">
            <Reveal className="lg:col-span-2">
              <article className="h-full rounded-3xl border border-border/70 bg-card/40 p-7 sm:p-10">
                <h2 className="font-display text-2xl font-bold sm:text-3xl">Our story</h2>
                <p className="mt-5 text-sm leading-relaxed text-muted-foreground sm:text-base whitespace-pre-wrap">
                  {story}
                </p>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base whitespace-pre-wrap">
                  {difference}
                </p>
              </article>
            </Reveal>

            <Reveal delay={120}>
              <article className="h-full rounded-3xl border border-neon/30 bg-neon/[0.06] p-7 sm:p-10">
                <h2 className="font-display text-2xl font-bold sm:text-3xl">Our mission</h2>
                <p className="mt-5 text-sm leading-relaxed text-muted-foreground sm:text-base whitespace-pre-wrap">
                  {mission}
                </p>
                <p className="mt-6 font-display text-lg font-semibold text-neon text-glow">
                  One team. One system. Five services.
                </p>
              </article>
            </Reveal>
          </section></React.Fragment>;
              case "AboutTimeline": return <React.Fragment key={sec.id}><section className="mt-24">
            <Reveal className="text-center">
              <p className="text-xs uppercase tracking-[0.3em] text-neon">Milestones</p>
              <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl">
                {tNormal} {tHighlight && <span className="text-neon">{tHighlight}</span>}
              </h2>
            </Reveal>

            <ol className="relative mx-auto mt-14 max-w-3xl">
              <span
                aria-hidden
                className="absolute left-[13px] top-2 h-[calc(100%-1rem)] w-px bg-gradient-to-b from-neon/60 via-neon/25 to-transparent sm:left-[15px]"
              />
              {milestones.map((m, i) => (
                <Reveal
                  as="li"
                  key={m.title}
                  delay={i * 110}
                  className="relative block pb-10 pl-12 sm:pl-16"
                >
                  <span
                    aria-hidden
                    className="absolute left-0 top-1.5 flex h-7 w-7 items-center justify-center rounded-full border border-neon/50 bg-background sm:h-8 sm:w-8"
                  >
                    <span className="h-2.5 w-2.5 rounded-full bg-neon shadow-[0_0_18px_2px_var(--neon)]" />
                  </span>
                  <p className="text-xs uppercase tracking-[0.25em] text-neon">{m.year}</p>
                  <h3 className="mt-2 font-display text-lg font-semibold sm:text-xl">{m.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{m.body}</p>
                </Reveal>
              ))}
            </ol>
          </section></React.Fragment>;
              case "AboutSkills": return <React.Fragment key={sec.id}><section className="mt-16">
            <Reveal className="text-center">
              <p className="text-xs uppercase tracking-[0.3em] text-neon">Expertise</p>
              <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl">
                {sNormal} {sHighlight && <span className="text-neon">{sHighlight}</span>}
              </h2>
            </Reveal>

            <div className="mt-12 grid gap-5 lg:grid-cols-2">
              {skills.map((s, i) => (
                <SkillMeter key={s.label} {...s} delay={i * 120} />
              ))}
            </div>
          </section></React.Fragment>;
              case "AboutCTA": return <React.Fragment key={sec.id}><Reveal className="mt-20 text-center" delay={80}>
            <h2 className="font-display text-3xl font-bold sm:text-4xl">
              Ready to build your <span className="text-neon text-glow">growth system?</span>
            </h2>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button variant="neon" size="xl" asChild>
                <a href="/#contact">Start a Project</a>
              </Button>
              <Button variant="neonOutline" size="xl" asChild>
                <Link to="/portfolio">View Our Work</Link>
              </Button>
            </div>
          </Reveal></React.Fragment>;
              case "TextImage": return <TextImageSection key={sec.id} payload={sec.payload} />;
              case "CustomCTA": return <CTASection key={sec.id} payload={sec.payload} />;
              default: return null;
            }
          })}
        </div>
      </main>
      <Footer />
    </div>
  );

}
