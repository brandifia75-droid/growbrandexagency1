import React from 'react';
import { Link } from '@tanstack/react-router';

// We'll define simple user-created section components here to avoid polluting the main files.

export function TextImageSection({ payload }: { payload: any }) {
  const ctaPath = payload.ctaLink?.split("#")[0] || "/";
  const ctaHash = payload.ctaLink?.includes("#") ? payload.ctaLink.split("#")[1] : undefined;
  
  return (
    <section className="py-24 px-5 sm:px-8">
      <div className="mx-auto max-w-7xl grid gap-12 lg:grid-cols-2 items-center">
        <div>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">{payload.heading}</h2>
          <p className="mt-6 text-muted-foreground leading-relaxed whitespace-pre-wrap">{payload.description}</p>
          {payload.ctaText && (
            <div className="mt-8">
              <Link to={ctaPath} hash={ctaHash} className="inline-flex items-center justify-center rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90 glow-neon">
                {payload.ctaText}
              </Link>
            </div>
          )}
        </div>
        {payload.image && (
          <div className="relative aspect-square sm:aspect-[4/3] lg:aspect-auto lg:h-[600px] overflow-hidden rounded-3xl border border-border/50">
            <img src={payload.image} alt={payload.heading} loading="lazy" decoding="async" className="h-full w-full object-cover" />
          </div>
        )}
      </div>
    </section>
  );
}

export function CTASection({ payload }: { payload: any }) {
  const btnPath = payload.buttonLink?.split("#")[0] || "/";
  const btnHash = payload.buttonLink?.includes("#") ? payload.buttonLink.split("#")[1] : undefined;

  return (
    <section className="py-24 px-5 sm:px-8">
      <div className="mx-auto max-w-4xl text-center rounded-3xl border border-neon/30 bg-neon/[0.03] p-10 sm:p-16">
        <h2 className="font-display text-3xl font-bold sm:text-5xl">{payload.heading}</h2>
        <p className="mt-6 text-lg text-muted-foreground">{payload.description}</p>
        {payload.buttonText && (
          <div className="mt-10">
            <Link to={btnPath} hash={btnHash} className="inline-flex items-center justify-center rounded-xl bg-primary px-8 py-4 text-base font-semibold text-primary-foreground transition-all hover:bg-primary/90 glow-neon">
              {payload.buttonText}
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
