import { Counter } from "./Counter";
import { num, useSite } from "@/lib/site-content";

export function Stats() {
  const { settings } = useSite();

  const stats = [
    { value: num(settings, "stats", "projects", 150), suffix: "+", label: "Projects Delivered" },
    { value: num(settings, "stats", "clients", 80), suffix: "+", label: "Happy Clients" },
    { value: num(settings, "stats", "services", 5), suffix: "", label: "Services Offered" },
    {
      value: num(settings, "stats", "rating", 4.9),
      suffix: "",
      decimals: 1,
      label: "Average Rating",
    },
  ];

  return (
    <section className="px-5 py-16 sm:px-8 sm:py-20">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
        {stats.map((s) => (
          <Counter key={s.label} {...s} />
        ))}
      </div>
    </section>
  );
}
