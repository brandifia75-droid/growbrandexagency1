import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Quote, Star } from "lucide-react";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";
import { cn } from "@/lib/utils";
import { txt, useSite } from "@/lib/site-content";

const fallbackTestimonials = [
  {
    quote:
      "GrowBrandex rebuilt our brand and website in six weeks. Our inbound leads tripled and we finally look like the category leader we are.",
    name: "Amara Chen",
    role: "Founder, Nexa Supply",
  },
  {
    quote:
      "The AI UGC ads outperformed our agency-produced creative at a fraction of the cost. Genuinely the best marketing spend we've made.",
    name: "Daniel Ortiz",
    role: "CMO, Vera Skincare",
  },
  {
    quote:
      "Clear communication, premium design, real results. They treat our growth like it's their own business.",
    name: "Sofia Rahman",
    role: "Director, Northline Interiors",
  },
];

export function Testimonials() {
  const { settings, testimonials: siteTestimonials } = useSite();

  const displayTestimonials =
    siteTestimonials.length > 0
      ? siteTestimonials.map((t) => ({ name: t.author, quote: t.quote, role: t.role }))
      : fallbackTestimonials;

  const [index, setIndex] = useState(0);
  const next = useCallback(
    () => setIndex((i) => (i + 1) % displayTestimonials.length),
    [displayTestimonials.length],
  );
  const prev = () =>
    setIndex((i) => (i - 1 + displayTestimonials.length) % displayTestimonials.length);

  useEffect(() => {
    const t = setInterval(next, 6000);
    return () => clearInterval(t);
  }, [next]);

  return (
    <section id="testimonials" className="px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-4xl">
        <SectionHeading
          eyebrow={txt(settings, "home", "testimonialsEyebrow", "Testimonials")}
          title={txt(settings, "home", "testimonialsTitle", "Clients who grew with us")}
        />
        <Reveal className="mt-12" delay={100}>
          <div className="overflow-hidden rounded-3xl border border-border/70 bg-card/45 backdrop-blur-md">
            <div
              className="flex transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
              style={{ transform: `translateX(-${index * 100}%)` }}
            >
              {displayTestimonials.map((t) => (
                <blockquote key={t.name} className="w-full shrink-0 p-8 sm:p-12">
                  <Quote className="text-neon" size={28} />
                  <p className="mt-6 font-display text-xl leading-relaxed sm:text-2xl">
                    “{t.quote}”
                  </p>
                  <footer className="mt-8 flex items-center justify-between gap-4">
                    <div>
                      <p className="font-semibold">{t.name}</p>
                      <p className="text-sm text-muted-foreground">{t.role}</p>
                    </div>
                    <div className="flex gap-1 text-neon">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} size={15} fill="currentColor" />
                      ))}
                    </div>
                  </footer>
                </blockquote>
              ))}
            </div>
          </div>
          <div className="mt-6 flex items-center justify-center gap-4">
            <button
              type="button"
              aria-label="Previous testimonial"
              onClick={prev}
              className="rounded-full border border-border/70 p-2 text-muted-foreground transition-colors hover:border-neon/60 hover:text-neon"
            >
              <ChevronLeft size={18} />
            </button>
            <div className="flex gap-2">
              {displayTestimonials.map((t, i) => (
                <button
                  key={t.name}
                  type="button"
                  aria-label={`Show testimonial ${i + 1}`}
                  onClick={() => setIndex(i)}
                  className={cn(
                    "h-2 rounded-full transition-all duration-300",
                    i === index ? "w-7 bg-neon" : "w-2 bg-border",
                  )}
                />
              ))}
            </div>
            <button
              type="button"
              aria-label="Next testimonial"
              onClick={next}
              className="rounded-full border border-border/70 p-2 text-muted-foreground transition-colors hover:border-neon/60 hover:text-neon"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
