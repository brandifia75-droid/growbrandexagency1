import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import defaultLogo from "@/assets/growbrandex-logo.png.asset.json";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useSite } from "@/lib/site-content";

const defaultLinks = [
  { label: "Home", href: "/", route: true },
  { label: "Services", href: "/services", route: true },
  { label: "Why Choose Us", href: "/#why-choose-us", route: false },
  { label: "About", href: "/about", route: true },
  { label: "Work", href: "/#work", route: false },
  { label: "Portfolio", href: "/portfolio", route: true },
  { label: "Testimonials", href: "/#testimonials", route: false },
  { label: "Contact", href: "/#contact", route: false },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { settings } = useSite();

  const logoUrl = settings?.["branding"]?.["logo_url"] || defaultLogo.url;
  const siteName = settings?.["branding"]?.["site_name"] || "GrowBrandex";

  const savedNav = settings?.['navigation']?.['items'] as typeof defaultLinks | undefined;

  let currentNav = savedNav ? [...savedNav] : [...defaultLinks];
  if (savedNav && !currentNav.find((item) => item.href === "/")) {
    currentNav.unshift({ label: "Home", href: "/", route: true, visible: true } as any);
  }
  if (savedNav && !currentNav.find((item) => item.href === "/#why-choose-us")) {
    const servicesIndex = currentNav.findIndex((i) => i.href === "/services");
    const insertIdx = servicesIndex !== -1 ? servicesIndex + 1 : 0;
    currentNav.splice(insertIdx, 0, { label: "Why Choose Us", href: "/#why-choose-us", route: false, visible: true } as any);
  }

  const activeLinks = currentNav.filter(
    (item) => (item as { visible?: boolean }).visible !== false,
  );

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "border-b border-border/60 bg-background/80 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <nav className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 sm:px-8">
        <Link to="/" className="flex items-center">
          {typeof logoUrl === "string" ? (
            <img src={logoUrl} alt={`${siteName} logo`} className="h-6 w-auto sm:h-7" />
          ) : (
            <span className="font-display font-bold text-xl">{String(siteName)}</span>
          )}
        </Link>
        <ul className="hidden items-center gap-9 md:flex">
          {activeLinks.map((l) => {
            const path = l.href.split("#")[0] || "/";
            const hash = l.href.includes("#") ? l.href.split("#")[1] : undefined;
            return (
              <li key={l.href}>
                <Link
                  to={path}
                  hash={hash}
                  className="text-sm font-medium text-muted-foreground transition-colors hover:text-neon"
                  activeProps={{ className: "text-neon" }}
                >
                  {l.label}
                </Link>
              </li>
            );
          })}
        </ul>

        <div className="hidden md:flex items-center gap-4">
          <Button variant="neon" size="sm" asChild>
            <Link to="/" hash="contact">Start a Project</Link>
          </Button>
        </div>

        <div className="flex md:hidden items-center gap-2">
        <button
          type="button"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
          className="rounded-md border border-border/70 p-2 text-foreground md:hidden"
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
        </div>
      </nav>

      {open && (
        <div className="animate-fade-in border-t border-border/60 bg-background/95 px-5 pb-6 pt-4 backdrop-blur-xl md:hidden">
          <ul className="flex flex-col gap-4">
            {activeLinks.map((l) => {
              const path = l.href.split("#")[0] || "/";
              const hash = l.href.includes("#") ? l.href.split("#")[1] : undefined;
              return (
                <li key={l.href}>
                  <Link
                    to={path}
                    hash={hash}
                    onClick={() => setOpen(false)}
                    className="block text-base text-muted-foreground transition-colors hover:text-neon"
                  >
                    {l.label}
                  </Link>
                </li>
              );
            })}
          </ul>
          <Button variant="neon" className="mt-5 w-full" asChild>
            <Link to="/" hash="contact" onClick={() => setOpen(false)}>
              Start a Project
            </Link>
          </Button>
        </div>
      )}
    </header>
  );
}
