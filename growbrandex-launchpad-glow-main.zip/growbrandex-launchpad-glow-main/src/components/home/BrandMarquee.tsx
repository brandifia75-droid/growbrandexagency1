import { Reveal } from "./Reveal";
import { txt, useSite } from "@/lib/site-content";

const brands = [
  "NEXA SUPPLY",
  "ORBIT FINANCE",
  "LUMEN STUDIO",
  "VERA SKINCARE",
  "NORTHLINE",
  "KITE & CO.",
  "AURORA LABS",
  "PEAKFORM",
];

export function BrandMarquee() {
  const { settings } = useSite();
  return (
    <section className="py-14 sm:py-20">
      <Reveal className="px-5 text-center sm:px-8">
        <p className="text-xs font-semibold uppercase tracking-[0.28em] text-muted-foreground">
          {txt(settings, "home", "brandsTitle", "Brands we've worked with")}
        </p>
      </Reveal>

      <div className="relative mt-10 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_12%,black_88%,transparent)]">
        <div className="animate-marquee flex w-max gap-14 pr-14 will-change-transform">
          {[...brands, ...brands].map((b, i) => (
            <span
              key={`${b}-${i}`}
              className="font-display text-lg font-semibold tracking-[0.14em] text-muted-foreground/70 transition-colors hover:text-neon sm:text-2xl"
            >
              {b}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
