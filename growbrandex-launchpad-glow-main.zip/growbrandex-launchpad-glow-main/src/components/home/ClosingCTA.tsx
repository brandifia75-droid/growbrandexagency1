import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "./Reveal";
import { useSite, txt } from "@/lib/site-content";
import { ContactForm } from "./ContactForm";

export function ClosingCTA() {
  const { settings } = useSite();
  const title = txt(settings, "home", "ctaTitle", "Ready to build a brand that grows?");
  const subtitle = txt(
    settings,
    "home",
    "ctaSubtitle",
    "Tell us where you want to be in 12 months. We'll design the brand, build the platform and run the content that gets you there.",
  );
  const button = txt(settings, "home", "ctaButton", "Start a Project");
  const email = txt(settings, "contact", "email", "hello@growbrandex.com");

  // A basic heuristic to extract the highlight: we assume the last 2 words are highlighted if no highlight logic is specified
  // Wait, the prompt says "Do NOT redesign ClosingCTA. Do NOT change: Layout, Typography, Spacing... Only change where the content comes from."
  // Wait, the existing CTA title has: Ready to build a brand <span className="text-neon text-glow">that grows?</span>
  // Let's just render the string, or maybe split the last two words to highlight.
  // Actually, I can just use a simple regex to wrap the last two words.
  const words = title.split(" ");
  const highlightWords = words.length > 2 ? words.splice(-2).join(" ") : "";
  const normalWords = words.join(" ");

  return (
    <section id="contact" className="px-5 py-20 sm:px-8 sm:py-28">
      <Reveal className="mx-auto max-w-5xl">
        <div className="relative overflow-hidden rounded-[2rem] border border-neon/30 bg-card/50 px-7 py-14 text-center backdrop-blur-md sm:px-14 sm:py-20">
          <div
            aria-hidden
            className="animate-drift-a pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-neon/25 blur-[120px]"
          />
          <h2 className="relative font-display text-3xl font-bold leading-tight sm:text-5xl">
            {normalWords}{" "}
            {highlightWords && <span className="text-neon text-glow">{highlightWords}</span>}
          </h2>
          <p className="relative mx-auto mt-5 max-w-xl text-base text-muted-foreground sm:text-lg">
            {subtitle}
          </p>
          <ContactForm />
        </div>
      </Reveal>
    </section>
  );
}
