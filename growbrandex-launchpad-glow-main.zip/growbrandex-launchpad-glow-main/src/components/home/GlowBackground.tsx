export function GlowBackground() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-background" />
      <div className="animate-drift-a absolute -left-40 -top-32 h-[38rem] w-[38rem] rounded-full bg-neon/25 blur-[140px] will-change-transform" />
      <div className="animate-drift-b absolute -right-48 top-1/3 h-[34rem] w-[34rem] rounded-full bg-neon-soft/20 blur-[150px] will-change-transform" />
      <div className="animate-drift-c absolute bottom-0 left-1/4 h-[30rem] w-[30rem] rounded-full bg-neon/15 blur-[160px] will-change-transform" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,transparent_0%,rgba(0,0,0,0.55)_75%)]" />
    </div>
  );
}
