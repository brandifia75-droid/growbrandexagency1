import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";
import { txt, useSite } from "@/lib/site-content";

export function Work() {
  const { settings, projects } = useSite();
  const featuredProjects = projects.filter((p) => p.featured).slice(0, 6);

  return (
    <section id="work" className="px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow={txt(settings, "home", "workEyebrow", "Featured work")}
          title={txt(settings, "home", "workTitle", "Selected projects")}
          subtitle={txt(
            settings,
            "home",
            "workSubtitle",
            "A snapshot of brands we've designed, built and scaled.",
          )}
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {featuredProjects.map((item, i) => (
            <Reveal key={item.id} delay={i * 80}>
              <figure className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card/40">
                <img
                  src={item.image_url}
                  alt={`${item.title} — ${item.category} project by GrowBrandex`}
                  width={900}
                  height={700}
                  loading="lazy"
                  className="aspect-[4/3] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />
                <figcaption className="absolute inset-x-0 bottom-0 translate-y-2 bg-gradient-to-t from-background via-background/80 to-transparent p-5 opacity-90 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                  <p className="text-xs uppercase tracking-[0.2em] text-neon">{item.category}</p>
                  <p className="mt-1 font-display text-lg font-semibold">{item.title}</p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 text-center" delay={120}>
          <Button variant="neon" size="xl" asChild>
            <Link to="/portfolio">View Full Portfolio</Link>
          </Button>
        </Reveal>
      </div>
    </section>
  );
}
