import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useSite } from "@/lib/site-content";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "@/lib/utils";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(1, "Contact number is required"),
  service: z.string().min(1, "Please select a service"),
  message: z.string().min(1, "Message is required"),
});

type FormValues = z.infer<typeof formSchema>;

export function ContactForm() {
  const { services } = useSite();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: "", email: "", phone: "", service: "", message: "" }
  });

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true);
    
    // Simulate network delay for realistic frontend UI behavior
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    setIsSubmitting(false);
    setIsSuccess(true);
  };

  const onError = () => {
    toast.error("Please fill in all required fields.");
  };

  return (
    <div className="mt-10 min-h-[480px]">
      <AnimatePresence mode="wait">
        {!isSuccess ? (
          <motion.form 
            key="form"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            onSubmit={handleSubmit(onSubmit, onError)} 
            className="flex flex-col gap-4 text-left bg-background/50 p-6 rounded-2xl border border-neon/20"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-muted-foreground">Full Name</Label>
                <Input id="name" placeholder="John Doe" {...register("name")} className={cn("bg-background/80", errors.name && "border-red-500 focus-visible:ring-red-500")} />
                {errors.name && <p className="text-xs text-red-500">{errors.name.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-muted-foreground">Email Address</Label>
                <Input id="email" type="email" placeholder="john@example.com" {...register("email")} className={cn("bg-background/80", errors.email && "border-red-500 focus-visible:ring-red-500")} />
                {errors.email && <p className="text-xs text-red-500">{errors.email.message}</p>}
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-muted-foreground">Contact / Phone Number</Label>
                <Input id="phone" placeholder="+1 (555) 000-0000" {...register("phone")} className={cn("bg-background/80", errors.phone && "border-red-500 focus-visible:ring-red-500")} />
                {errors.phone && <p className="text-xs text-red-500">{errors.phone.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="service" className="text-muted-foreground">Service Needed</Label>
                <Select onValueChange={(val) => setValue("service", val, { shouldValidate: true })}>
                  <SelectTrigger className={cn("bg-background/80", errors.service && "border-red-500 focus:ring-red-500")}>
                    <SelectValue placeholder="Select a service" />
                  </SelectTrigger>
                  <SelectContent>
                    {services.map((s) => (
                      <SelectItem key={s.id} value={s.title}>{s.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.service && <p className="text-xs text-red-500">{errors.service.message}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message" className="text-muted-foreground">Message</Label>
              <Textarea id="message" placeholder="Tell us about your project..." rows={4} {...register("message")} className={cn("bg-background/80 resize-none", errors.message && "border-red-500 focus-visible:ring-red-500")} />
              {errors.message && <p className="text-xs text-red-500">{errors.message.message}</p>}
            </div>

            <Button type="submit" variant="neon" size="lg" disabled={isSubmitting} className="mt-2 w-full sm:w-auto self-start">
              {isSubmitting ? "Submitting..." : "Send Inquiry"}
            </Button>
          </motion.form>
        ) : (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="flex flex-col items-center justify-center gap-4 text-center bg-background/50 p-12 min-h-[480px] rounded-2xl border border-neon/20"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.2 }}
              className="flex items-center justify-center w-20 h-20 rounded-full bg-neon/10 text-neon mb-2"
            >
              <svg 
                className="w-10 h-10" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="3" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <motion.polyline
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
                  points="20 6 9 17 4 12"
                />
              </svg>
            </motion.div>
            <h3 className="text-3xl font-display font-bold text-foreground">Thank You!</h3>
            <p className="text-muted-foreground max-w-sm text-lg">
              Our team will contact you soon.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
