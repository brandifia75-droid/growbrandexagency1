import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";
import { txt, useSite } from "@/lib/site-content";
import { icons } from "lucide-react";

export function Services() {
  const { settings, services } = useSite();

  return (
    <section id="services" className="px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow={txt(settings, "home", "servicesEyebrow", "What we do")}
          title={txt(settings, "home", "servicesTitle", "Five services, one growth engine")}
          subtitle={txt(
            settings,
            "home",
            "servicesSubtitle",
            "Everything your brand needs to look premium and perform online — under one roof.",
          )}
        />

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => {
            const IconComp = (icons as Record<string, any>)[s.icon || "Zap"] || icons.Zap;
            return (
              <Reveal key={s.id} delay={i * 90}>
                <article className="group flex h-full flex-col rounded-2xl border border-border/70 bg-card/45 p-7 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1.5 hover:border-neon/50">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-neon/35 bg-neon/10 text-neon transition-colors group-hover:bg-neon/20">
                    <IconComp size={22} />
                  </span>
                  <h3 className="mt-6 font-display text-xl font-semibold">{s.title}</h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                    {s.short_description}
                  </p>
                  <Button
                    variant="neonOutline"
                    size="sm"
                    className="mt-6 self-start rounded-full px-5"
                    asChild
                  >
                    <Link to="/" hash="contact">Get a Quote</Link>
                  </Button>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
