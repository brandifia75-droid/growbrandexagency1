import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";
import { useSite, txt } from "@/lib/site-content";
import { icons, CheckCircle } from "lucide-react";

export function WhyChooseUs() {
  const { settings, whyChooseUs } = useSite();

  if (!whyChooseUs || whyChooseUs.length === 0) return null;

  return (
    <section id="why-choose-us" className="px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow={txt(settings, "home", "whyChooseUsEyebrow", "Why Choose Us")}
          title={txt(settings, "home", "whyChooseUsTitle", "Our Approach to Growth")}
        />

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {whyChooseUs.map((item, i) => {
            const IconComp =
              (icons as Record<string, any>)[item.source || "CheckCircle"] || CheckCircle;
            return (
              <Reveal key={item.id} delay={i * 90}>
                <article className="group flex h-full flex-col rounded-2xl border border-border/70 bg-card/45 p-7 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1.5 hover:border-neon/50">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-neon/35 bg-neon/10 text-neon transition-colors group-hover:bg-neon/20">
                    <IconComp size={22} />
                  </span>
                  <h3 className="mt-6 font-display text-xl font-semibold">{item.title}</h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                    {item.description}
                  </p>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
