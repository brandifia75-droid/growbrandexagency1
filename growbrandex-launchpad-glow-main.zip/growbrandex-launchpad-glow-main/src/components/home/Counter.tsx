import { useEffect, useState } from "react";
import { useReveal } from "@/hooks/use-reveal";

export function Counter({
  value,
  suffix = "",
  decimals = 0,
  label,
}: {
  value: number;
  suffix?: string;
  decimals?: number;
  label: string;
}) {
  const { ref, visible } = useReveal<HTMLDivElement>(0.4);
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!visible) return;
    const duration = 1600;
    const start = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(value * eased);
      if (p < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [visible, value]);

  return (
    <div
      ref={ref}
      data-visible={visible}
      className="reveal rounded-2xl border border-border/70 bg-card/50 p-6 text-center backdrop-blur-sm transition-colors hover:border-neon/50 sm:p-8"
    >
      <div className="font-display text-4xl font-bold text-neon text-glow sm:text-5xl">
        {display.toFixed(decimals)}
        {suffix}
      </div>
      <p className="mt-2 text-sm uppercase tracking-[0.18em] text-muted-foreground">{label}</p>
    </div>
  );
}
