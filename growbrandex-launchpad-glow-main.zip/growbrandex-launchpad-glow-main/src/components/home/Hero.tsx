import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles } from "lucide-react";
import logo from "@/assets/growbrandex-logo.png.asset.json";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { num, txt, useSite } from "@/lib/site-content";

function Fade({
  show,
  delay,
  children,
  className,
}: {
  show: boolean;
  delay: number;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      data-visible={show}
      style={{ transitionDelay: `${delay}ms` }}
      className={cn("reveal", className)}
    >
      {children}
    </div>
  );
}

export function Hero() {
  const { settings } = useSite();
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setReady(true), 80);
    return () => clearTimeout(t);
  }, []);

  const title = txt(settings, "home", "heroTitle", "We Build Brands");
  const highlight = txt(settings, "home", "heroHighlight", "That Grow");
  const projects = num(settings, "stats", "projects", 150);
  const clients = num(settings, "stats", "clients", 80);
  const rating = num(settings, "stats", "rating", 4.9);

  return (
    <section id="top" className="relative px-5 pb-20 pt-32 sm:px-8 sm:pb-28 sm:pt-40">
      <div className="mx-auto grid max-w-7xl items-center gap-14 lg:grid-cols-[1.15fr_0.85fr] lg:gap-20">
        <div>
          <Fade show={ready} delay={0}>
            <img
              src={logo.url}
              alt="GrowBrandex — digital growth agency"
              width={520}
              height={104}
              loading="eager"
              fetchPriority="high"
              decoding="async"
              className="h-10 w-auto sm:h-14"
            />
          </Fade>

          <Fade show={ready} delay={160} className="mt-8">
            <h1 className="font-display text-[2.6rem] font-bold leading-[1.05] sm:text-6xl lg:text-7xl">
              {title}
              <br />
              <span className="text-neon text-glow">{highlight}</span>
            </h1>
          </Fade>

          <Fade show={ready} delay={320} className="mt-9 flex flex-col gap-4 sm:flex-row">
            <Button variant="neon" size="xl" asChild>
              <Link to="/" hash="contact">
                {txt(settings, "home", "ctaPrimary", "Start a Project")} <ArrowRight />
              </Link>
            </Button>
            <Button variant="neonOutline" size="xl" asChild>
              <Link to="/" hash="work">{txt(settings, "home", "ctaSecondary", "View Our Work")}</Link>
            </Button>
          </Fade>
        </div>

        <Fade show={ready} delay={420}>
          <div className="relative rounded-3xl border border-border/70 bg-card/40 p-8 backdrop-blur-md sm:p-10">
            <span className="inline-flex items-center gap-2 rounded-full border border-neon/40 px-3 py-1 text-xs font-medium uppercase tracking-[0.2em] text-neon">
              <Sparkles size={13} /> {txt(settings, "home", "heroEyebrow", "Full-service growth")}
            </span>
            <p className="mt-6 text-lg leading-relaxed text-muted-foreground sm:text-xl">
              {txt(
                settings,
                "home",
                "heroSubtitle",
                "GrowBrandex is a full-service digital growth agency helping business owners build, launch and scale their brand online — from identity and websites to AI-powered content that converts.",
              )}
            </p>
            <div className="mt-8 flex flex-wrap gap-x-8 gap-y-4 border-t border-border/60 pt-6 text-sm text-muted-foreground">
              <span>
                <strong className="text-foreground">{projects}+</strong> Projects
              </span>
              <span>
                <strong className="text-foreground">{clients}+</strong> Clients
              </span>
              <span>
                <strong className="text-foreground">{rating}/5</strong> Rating
              </span>
            </div>
          </div>
        </Fade>
      </div>
    </section>
  );
}
