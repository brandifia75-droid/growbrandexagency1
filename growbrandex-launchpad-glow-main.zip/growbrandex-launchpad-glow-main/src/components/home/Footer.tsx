import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Linkedin, Twitter, Youtube } from "lucide-react";
import logo from "@/assets/growbrandex-logo.png.asset.json";
import { useSite, txt } from "@/lib/site-content";

const quickLinks = [
  { label: "Services", href: "/services" },
  { label: "About Us", href: "/about" },
  { label: "Featured Work", href: "/#work" },
  { label: "Testimonials", href: "/#testimonials" },
  { label: "Portfolio", href: "/portfolio" },
  { label: "Contact", href: "/#contact" },
];

export function Footer() {
  const { settings, services } = useSite();
  const email = txt(settings, "contact", "email", "hello@growbrandex.com");
  const instagram = txt(settings, "contact", "instagram");
  const linkedin = txt(settings, "contact", "linkedin");
  const twitter = txt(settings, "contact", "twitter");
  const facebook = txt(settings, "contact", "facebook");
  const youtube = txt(settings, "contact", "youtube");

  const socials = [
    { Icon: Instagram, label: "Instagram", href: instagram },
    { Icon: Linkedin, label: "LinkedIn", href: linkedin },
    { Icon: Twitter, label: "X", href: twitter },
    { Icon: Facebook, label: "Facebook", href: facebook },
    { Icon: Youtube, label: "YouTube", href: youtube },
  ].filter((s) => s.href); // Only show socials that have a URL configured

  // Fallback to default socials if none are configured, just linking to #contact as before
  const displaySocials =
    socials.length > 0
      ? socials
      : [
          { Icon: Instagram, label: "Instagram", href: "/#contact" },
          { Icon: Linkedin, label: "LinkedIn", href: "/#contact" },
          { Icon: Twitter, label: "X", href: "/#contact" },
          { Icon: Facebook, label: "Facebook", href: "/#contact" },
          { Icon: Youtube, label: "YouTube", href: "/#contact" },
        ];

  return (
    <footer className="border-t border-border/60 bg-background/70 px-5 py-14 backdrop-blur-md sm:px-8">
      <div className="mx-auto grid max-w-7xl gap-10 sm:grid-cols-2 lg:grid-cols-4">
        <div className="lg:col-span-2">
          <img
            src={logo.url}
            alt="GrowBrandex logo"
            width={200}
            height={40}
            loading="lazy"
            decoding="async"
            className="h-8 w-auto"
          />
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted-foreground">
            A full-service digital growth agency helping business owners build and scale their brand
            online. We Build Brands That Grow.
          </p>
          <div className="mt-6 flex gap-3">
            {displaySocials.map(({ Icon, label, href }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                target={href.startsWith("http") ? "_blank" : undefined}
                rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-border/70 text-muted-foreground transition-all duration-300 hover:-translate-y-0.5 hover:border-neon/60 hover:text-neon"
              >
                <Icon size={17} />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-neon">
            Quick Links
          </h3>
          <ul className="mt-5 space-y-3 text-sm text-muted-foreground">
            {quickLinks.map((l) => {
              const path = l.href.split("#")[0] || "/";
              const hash = l.href.includes("#") ? l.href.split("#")[1] : undefined;
              return (
                <li key={l.label}>
                  <Link to={path} hash={hash} className="transition-colors hover:text-neon">
                    {l.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-neon">
            Services
          </h3>
          <ul className="mt-5 space-y-3 text-sm text-muted-foreground">
            {services.slice(0, 5).map((s) => (
              <li key={s.id}>{s.title}</li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mx-auto mt-12 flex max-w-7xl flex-col items-center justify-between gap-3 border-t border-border/60 pt-6 text-xs text-muted-foreground sm:flex-row">
        <p>© {new Date().getFullYear()} GrowBrandex. All rights reserved.</p>
        <p>{email}</p>
      </div>
    </footer>
  );
}
