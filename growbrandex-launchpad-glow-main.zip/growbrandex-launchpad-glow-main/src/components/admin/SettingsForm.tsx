import { useEffect, useState, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Save, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { updateSetting } from "@/lib/settings.functions";
import { uploadImage } from "@/lib/admin.functions";
import { siteContentQuery, type SiteContent } from "@/lib/site-content";
import type { Json } from "@/integrations/supabase/types";

export type SettingField = {
  name: string;
  label: string;
  type?: "text" | "textarea" | "number" | "image";
  help?: string;
};

export type SettingGroup = {
  key: string;
  title: string;
  description?: string;
  fields: SettingField[];
};

function valueToString(v: Json | undefined): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "string") return v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  return "";
}

function ImageFieldInput({
  value,
  onChange,
  id,
}: {
  value: string;
  onChange: (val: string) => void;
  id: string;
}) {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select a valid image file");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image size must be less than 5MB");
      return;
    }

    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Str = (reader.result as string).split(",")[1];
        const safeName = file.name.replace(/[^a-zA-Z0-9.-]/g, "_");
        const path = `brand/${Date.now()}-${safeName}`;

        const uploadData = await uploadImage({
          data: { path, base64: base64Str as string, contentType: file.type },
        });

        onChange(uploadData.url as string);
        toast.success("Image uploaded successfully");
        if (fileInputRef.current) fileInputRef.current.value = "";
      };
      reader.readAsDataURL(file);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to upload image");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Input id={id} value={(value as string) || ""} onChange={(e) => onChange(e.target.value as any)} className="flex-1" />
      <input
        type="file"
        accept="image/*"
        className="hidden"
        ref={fileInputRef}
        onChange={handleUpload}
      />
      <Button
        type="button"
        variant="secondary"
        onClick={() => fileInputRef.current?.click()}
        disabled={uploading}
      >
        {uploading ? "..." : <Upload className="h-4 w-4" />}
      </Button>
    </div>
  );
}

function GroupCard({
  group,
  settings,
}: {
  group: SettingGroup;
  settings: SiteContent["settings"];
}) {
  const queryClient = useQueryClient();
  const save = useServerFn(updateSetting);
  const source = settings?.[group.key] ?? {};

  const initial = () => {
    const out: Record<string, string> = {};
    for (const f of group.fields) out[f.name] = valueToString(source[f.name]);
    return out;
  };

  const [form, setForm] = useState<Record<string, string>>(initial);

  useEffect(() => {
    setForm(initial());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings, group.key]);

  const mutation = useMutation({
    mutationFn: async () => {
      // Preserve any fields in the group that this form does not expose.
      const merged: Record<string, Json> = { ...(source as Record<string, Json>) };
      for (const f of group.fields) {
        const raw = form[f.name] ?? "";
        if (f.type === "number") {
          const n = Number(raw);
          merged[f.name] = Number.isFinite(n) ? n : 0;
        } else {
          merged[f.name] = raw;
        }
      }
      return save({ data: { key: group.key, value: merged } });
    },
    onSuccess: async () => {
      toast.success(`${group.title} saved`);
      await queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
    },
    onError: (e: unknown) => {
      toast.error(`Could not save: ${e instanceof Error ? e.message : "unknown error"}`);
    },
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        mutation.mutate();
      }}
      className="animate-fade-in rounded-2xl border border-border/60 bg-card/60 p-6 backdrop-blur-xl"
    >
      <h2 className="font-display text-lg font-bold">{group.title}</h2>
      {group.description && (
        <p className="mt-1 text-sm text-muted-foreground">{group.description}</p>
      )}

      <div className="mt-6 grid gap-5 sm:grid-cols-2">
        {group.fields.map((f) => (
          <div
            key={f.name}
            className={f.type === "textarea" ? "sm:col-span-2 space-y-2" : "space-y-2"}
          >
            <Label htmlFor={`${group.key}-${f.name}`}>{f.label}</Label>
            {f.type === "textarea" ? (
              <Textarea
                id={`${group.key}-${f.name}`}
                rows={4}
                value={form[f.name] ?? ""}
                onChange={(e) => setForm((s) => ({ ...s, [f.name]: e.target.value }))}
              />
            ) : f.type === "image" ? (
              <ImageFieldInput
                id={`${group.key}-${f.name}`}
                value={form[f.name] ?? ""}
                onChange={(val) => setForm((s) => ({ ...s, [f.name]: val }))}
              />
            ) : (
              <Input
                id={`${group.key}-${f.name}`}
                type={f.type === "number" ? "number" : "text"}
                step={f.type === "number" ? "any" : undefined}
                value={form[f.name] ?? ""}
                onChange={(e) => setForm((s) => ({ ...s, [f.name]: e.target.value }))}
              />
            )}
            {f.help && <p className="text-xs text-muted-foreground">{f.help}</p>}
          </div>
        ))}
      </div>

      <div className="mt-6 flex items-center gap-3">
        <Button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Save className="mr-2 h-4 w-4" />
          )}
          {mutation.isPending ? "Saving…" : "Save changes"}
        </Button>
        {mutation.isSuccess && !mutation.isPending && (
          <span className="text-sm text-primary">Saved</span>
        )}
        {mutation.isError && !mutation.isPending && (
          <span className="text-sm text-destructive">
            {mutation.error instanceof Error ? mutation.error.message : "Save failed"}
          </span>
        )}
      </div>
    </form>
  );
}

export function SettingsForm({ groups }: { groups: SettingGroup[] }) {
  const { data, isPending, isError, error, refetch } = useQuery(siteContentQuery);

  if (isPending) {
    return (
      <div className="flex items-center gap-2 rounded-2xl border border-border/60 bg-card/60 p-6 text-sm text-muted-foreground backdrop-blur-xl">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading current content…
      </div>
    );
  }

  if (isError) {
    return (
      <div className="rounded-2xl border border-destructive/50 bg-card/60 p-6 backdrop-blur-xl">
        <p className="text-sm text-destructive">
          Could not load content: {error instanceof Error ? error.message : "unknown error"}
        </p>
        <Button variant="outline" className="mt-4" onClick={() => refetch()}>
          Try again
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {groups.map((g) => (
        <GroupCard key={g.title} group={g} settings={data.settings} />
      ))}
    </div>
  );
}
