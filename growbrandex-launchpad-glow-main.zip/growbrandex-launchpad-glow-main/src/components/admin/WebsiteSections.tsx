import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { 
  GripVertical, Eye, EyeOff, Edit, Trash2, Plus, 
  ArrowUp, ArrowDown, Save, X 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { updateSetting } from "@/lib/settings.functions";
import { useSite } from "@/lib/site-content";

const DEFAULT_SECTIONS = {
  home: [
    { id: "home-hero", type: "Hero", visible: true, order: 1, isCore: true },
    { id: "home-stats", type: "Stats", visible: true, order: 2, isCore: true },
    { id: "home-services", type: "Services", visible: true, order: 3, isCore: true },
    { id: "home-why-choose-us", type: "WhyChooseUs", visible: true, order: 4, isCore: true },
    { id: "home-work", type: "Work", visible: true, order: 5, isCore: true },
    { id: "home-testimonials", type: "Testimonials", visible: true, order: 6, isCore: true },
    { id: "home-brand-marquee", type: "BrandMarquee", visible: true, order: 7, isCore: true },
    { id: "home-cta", type: "ClosingCTA", visible: true, order: 8, isCore: true },
  ],
  about: [
    { id: "about-hero", type: "AboutHero", visible: true, order: 1, isCore: true },
    { id: "about-story", type: "AboutStory", visible: true, order: 2, isCore: true },
    { id: "about-timeline", "type": "AboutTimeline", visible: true, order: 3, isCore: true },
    { id: "about-skills", "type": "AboutSkills", visible: true, order: 4, isCore: true },
    { id: "about-cta", "type": "AboutCTA", visible: true, order: 5, isCore: true },
  ]
};

export function AdminWebsiteSections() {
  const { settings } = useSite();
  const queryClient = useQueryClient();
  const [activePage, setActivePage] = useState("home");

  const [sections, setSections] = useState<any[]>(() => {
    return (settings?.['page_sections']?.[activePage] as any[]) || DEFAULT_SECTIONS[activePage as keyof typeof DEFAULT_SECTIONS] || [];
  });

  const [editSection, setEditSection] = useState<any | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  // When tab changes
  const handlePageChange = (page: string) => {
    setActivePage(page);
    setSections((settings?.['page_sections']?.[page] as any[]) || DEFAULT_SECTIONS[page as keyof typeof DEFAULT_SECTIONS] || []);
    setEditSection(null);
    setIsAdding(false);
  };

  const mutation = useMutation({
    mutationFn: async (newSections: any[]) => {
      const current = settings?.['page_sections'] || {};
      return updateSetting({
        data: {
          key: "page_sections",
          value: { ...current, [activePage]: newSections },
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["site-content"] });
      toast.success("Sections saved successfully");
    },
    onError: (err: any) => {
      toast.error(err.message || "Failed to save sections");
    }
  });

  const handleSaveAll = () => {
    const sorted = [...sections].map((s, i) => ({ ...s, order: i + 1 }));
    setSections(sorted);
    mutation.mutate(sorted);
  };

  const moveUp = (index: number) => {
    if (index === 0) return;
    const newSections = [...sections];
    [newSections[index - 1], newSections[index]] = [newSections[index], newSections[index - 1]];
    setSections(newSections);
  };

  const moveDown = (index: number) => {
    if (index === sections.length - 1) return;
    const newSections = [...sections];
    [newSections[index + 1], newSections[index]] = [newSections[index], newSections[index + 1]];
    setSections(newSections);
  };

  const toggleVisibility = (index: number) => {
    const newSections = [...sections];
    newSections[index].visible = !newSections[index].visible;
    setSections(newSections);
  };

  const handleDelete = (index: number) => {
    if (sections[index].isCore) return;
    if (window.confirm("Are you sure you want to delete this section?")) {
      const newSections = [...sections];
      newSections.splice(index, 1);
      setSections(newSections);
    }
  };

  const handleEditSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAdding) {
      setSections([...sections, { ...editSection, id: `custom-${Date.now()}`, isCore: false, visible: true }]);
    } else {
      setSections(sections.map(s => s.id === editSection.id ? editSection : s));
    }
    setEditSection(null);
    setIsAdding(false);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="font-display text-2xl font-bold">Website Sections</h2>
        <p className="text-muted-foreground mt-2">Manage the layout and content of your public pages.</p>
      </div>

      <div className="flex gap-4 border-b border-border/40 pb-2">
        <button
          className={`pb-2 px-1 border-b-2 transition-colors ${activePage === "home" ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => handlePageChange("home")}
        >
          Home Page
        </button>
        <button
          className={`pb-2 px-1 border-b-2 transition-colors ${activePage === "about" ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => handlePageChange("about")}
        >
          About Page
        </button>
      </div>

      {editSection ? (
        <div className="rounded-xl border border-border/50 bg-card p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-display text-lg font-bold">{isAdding ? "Add New Section" : "Edit Section"}</h3>
            <button onClick={() => { setEditSection(null); setIsAdding(false); }} className="text-muted-foreground hover:text-foreground">
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <form onSubmit={handleEditSave} className="space-y-6">
            {isAdding && (
              <div className="space-y-2">
                <Label>Section Type</Label>
                <select 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                  value={editSection.type || ""}
                  onChange={e => setEditSection({ ...editSection, type: e.target.value, payload: {} })}
                  required
                >
                  <option value="" disabled>Select a type...</option>
                  <option value="TextImage">Text + Image</option>
                  <option value="CustomCTA">Call to Action (CTA)</option>
                </select>
              </div>
            )}

            {editSection.type === "TextImage" && (
              <>
                <div className="space-y-2">
                  <Label>Heading</Label>
                  <Input value={editSection.payload?.heading || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, heading: e.target.value}})} required />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea value={editSection.payload?.description || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, description: e.target.value}})} required rows={4} />
                </div>
                <div className="space-y-2">
                  <Label>Image URL (Optional)</Label>
                  <Input value={editSection.payload?.image || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, image: e.target.value}})} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>CTA Text (Optional)</Label>
                    <Input value={editSection.payload?.ctaText || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, ctaText: e.target.value}})} />
                  </div>
                  <div className="space-y-2">
                    <Label>CTA Link (Optional)</Label>
                    <Input value={editSection.payload?.ctaLink || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, ctaLink: e.target.value}})} />
                  </div>
                </div>
              </>
            )}

            {editSection.type === "CustomCTA" && (
              <>
                <div className="space-y-2">
                  <Label>Heading</Label>
                  <Input value={editSection.payload?.heading || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, heading: e.target.value}})} required />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea value={editSection.payload?.description || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, description: e.target.value}})} rows={3} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Button Text</Label>
                    <Input value={editSection.payload?.buttonText || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, buttonText: e.target.value}})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Button Link</Label>
                    <Input value={editSection.payload?.buttonLink || ""} onChange={e => setEditSection({...editSection, payload: {...editSection.payload, buttonLink: e.target.value}})} />
                  </div>
                </div>
              </>
            )}

            {editSection.isCore && (
              <div className="p-4 bg-secondary/50 rounded-lg text-sm text-muted-foreground border border-border/50">
                This is a core section. Its content is managed from other areas of the admin panel (like Home settings or Portfolio). You can only reorder or hide it here.
              </div>
            )}

            <div className="pt-4 flex justify-end gap-3 border-t border-border/50">
              <Button type="button" variant="outline" onClick={() => { setEditSection(null); setIsAdding(false); }}>Cancel</Button>
              <Button type="submit">Save Settings</Button>
            </div>
          </form>
        </div>
      ) : (
        <>
          <div className="rounded-xl border border-border/50 bg-card overflow-hidden">
            <div className="divide-y divide-border/50">
              {sections.sort((a,b)=>a.order-b.order).map((section, index) => (
                <div key={section.id} className={`p-4 flex items-center gap-4 transition-colors ${!section.visible ? 'opacity-60 bg-muted/20' : ''}`}>
                  <div className="flex flex-col gap-1">
                    <button onClick={() => moveUp(index)} disabled={index === 0} className="text-muted-foreground hover:text-foreground disabled:opacity-30"><ArrowUp className="w-4 h-4" /></button>
                    <button onClick={() => moveDown(index)} disabled={index === sections.length - 1} className="text-muted-foreground hover:text-foreground disabled:opacity-30"><ArrowDown className="w-4 h-4" /></button>
                  </div>
                  
                  <div className="flex-1">
                    <h4 className="font-semibold">{section.type}</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      {section.isCore ? "Core Section" : "Custom Section"} 
                      {!section.visible && " • Hidden"}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" onClick={() => toggleVisibility(index)} title={section.visible ? "Hide" : "Show"}>
                      {section.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    </Button>
                    
                    {(!section.isCore) && (
                      <Button variant="ghost" size="icon" onClick={() => { setIsAdding(false); setEditSection({ ...section }); }}>
                        <Edit className="w-4 h-4" />
                      </Button>
                    )}

                    {!section.isCore && (
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(index)} className="text-destructive hover:bg-destructive/10 hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
              {sections.length === 0 && (
                <div className="p-8 text-center text-muted-foreground">
                  No sections found for this page.
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between pt-4">
            <Button variant="outline" onClick={() => { setIsAdding(true); setEditSection({ visible: true, isCore: false }); }}>
              <Plus className="w-4 h-4 mr-2" /> Add Section
            </Button>
            
            <Button onClick={handleSaveAll} disabled={mutation.isPending}>
              <Save className="w-4 h-4 mr-2" /> 
              {mutation.isPending ? "Saving..." : "Save Layout"}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
