import { useState } from "react";
import { Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  Award,
  CheckCircle,
  Contact,
  Image as ImageIcon,
  Info,
  Inbox,
  LayoutDashboard,
  List,
  LogOut,
  Menu,
  MessageSquareQuote,
  Home as HomeIcon,
  Palette,
  Briefcase,
  Sparkles,
  UserCog,
  X,
} from "lucide-react";
import logo from "@/assets/growbrandex-logo.png.asset.json";
import { Button } from "@/components/ui/button";
import { GlowBackground } from "@/components/home/GlowBackground";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export const adminNav = [
  { to: "/admin", label: "Overview", icon: LayoutDashboard, exact: true },
  { to: "/admin/home", label: "Home", icon: HomeIcon },
  { to: "/admin/about", label: "About", icon: Info },
  { to: "/admin/services", label: "Services", icon: Sparkles },
  { to: "/admin/portfolio", label: "Portfolio", icon: Briefcase },
  { to: "/admin/testimonials", label: "Testimonials", icon: MessageSquareQuote },
  { to: "/admin/why-choose-us", label: "Why Choose Us", icon: CheckCircle },
  { to: "/admin/contact", label: "Contact", icon: Contact },
  { to: "/admin/sections", label: "Website Sections", icon: LayoutDashboard },
  { to: "/admin/navigation", label: "Navigation", icon: List },
  { to: "/admin/images", label: "Images", icon: ImageIcon },
  { to: "/admin/submissions", label: "Submissions", icon: Inbox },
  { to: "/admin/account", label: "Account", icon: UserCog },
] as const;

export function AdminShell({ email }: { email?: string | undefined }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const current =
    adminNav.find((i) =>
      i.to === "/admin" ? pathname.replace(/\/$/, "") === "/admin" : pathname.startsWith(i.to),
    ) ?? adminNav[0];

  async function signOut() {
    setBusy(true);
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/admin-login", replace: true });
  }

  const navList = (
    <nav className="flex flex-col gap-1">
      {adminNav.map((item) => {
        const active = item === current;
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={() => setOpen(false)}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all",
              active
                ? "bg-primary/15 text-primary glow-neon"
                : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
            )}
          >
            <Icon className="h-4 w-4 shrink-0" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="relative min-h-screen bg-background text-foreground">
      <GlowBackground />

      <div className="relative flex min-h-screen">
        {/* Desktop sidebar */}
        <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-border/60 bg-card/50 p-4 backdrop-blur-xl lg:flex">
          <Link to="/" className="mb-6 block">
            <img src={logo.url} alt="GrowBrandex" className="h-8 w-auto" />
          </Link>
          {navList}
          <div className="mt-auto pt-6">
            <p className="truncate px-3 pb-2 text-xs text-muted-foreground">{email}</p>
            <Button variant="outline" className="w-full" onClick={signOut} disabled={busy}>
              <LogOut className="mr-2 h-4 w-4" />
              {busy ? "Signing out…" : "Log out"}
            </Button>
          </div>
        </aside>

        {/* Mobile drawer */}
        {open && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div
              className="absolute inset-0 bg-background/80 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />
            <div className="animate-scale-in absolute left-0 top-0 flex h-full w-72 flex-col border-r border-border/60 bg-card p-4">
              <div className="mb-6 flex items-center justify-between">
                <img src={logo.url} alt="GrowBrandex" className="h-8 w-auto" />
                <button aria-label="Close menu" onClick={() => setOpen(false)}>
                  <X className="h-5 w-5" />
                </button>
              </div>
              {navList}
              <div className="mt-auto pt-6">
                <Button variant="outline" className="w-full" onClick={signOut} disabled={busy}>
                  <LogOut className="mr-2 h-4 w-4" /> Log out
                </Button>
              </div>
            </div>
          </div>
        )}

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border/60 bg-background/70 px-4 py-4 backdrop-blur-xl sm:px-6">
            <button className="lg:hidden" aria-label="Open menu" onClick={() => setOpen(true)}>
              <Menu className="h-5 w-5" />
            </button>
            <div className="min-w-0">
              <h1 className="truncate font-display text-lg font-bold sm:text-xl">
                {current.label}
              </h1>
              <p className="truncate text-xs text-muted-foreground">GrowBrandex Admin Panel</p>
            </div>
            <Link to="/" className="ml-auto text-xs text-muted-foreground hover:text-primary">
              View site
            </Link>
          </header>

          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
}

export function AdminPlaceholder({ title, description }: { title: string; description: string }) {
  return (
    <div className="animate-fade-in rounded-2xl border border-border/60 bg-card/60 p-8 backdrop-blur-xl">
      <h2 className="font-display text-xl font-bold">{title}</h2>
      <p className="mt-3 max-w-xl text-sm text-muted-foreground">{description}</p>
      <p className="mt-6 inline-flex rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs text-primary">
        Coming in the next step
      </p>
    </div>
  );
}
