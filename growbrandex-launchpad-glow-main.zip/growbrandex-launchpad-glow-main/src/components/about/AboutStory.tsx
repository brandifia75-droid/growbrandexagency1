
import { useSite, txt } from "@/lib/site-content";
import { Reveal } from "@/components/home/Reveal";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function AboutStory() {
  const { settings } = useSite();
  const eyebrow = txt(settings, "about", "eyebrow", "About us");
  const title = txt(settings, "about", "title", "We build brands that grow");
  const story = txt(settings, "about", "story", "We began by giving local business owners a more professional presence online — logos, identities and the small details that make a business look established. Over time we expanded into a full-service digital agency covering design, development and AI-powered content, because our clients kept asking us to handle more of their growth in one place.");
  const difference = txt(settings, "about", "difference", "What makes us different is that we don't just deliver a design or a video. We build a complete brand growth system — combining creative, technical and AI-driven content — so business owners can focus on running their business while we handle their online presence.");
  const mission = txt(settings, "about", "mission", "To help business owners grow real, recognizable brands — without needing five different freelancers.");
  const timelineTitle = txt(settings, "about", "timelineTitle", "How we grew");
  const skillsTitle = txt(settings, "about", "skillsTitle", "Where we're strongest");

  const words = title.split(" ");
  const titleHighlight = words.length > 1 ? words.pop() : "";
  const titleNormal = words.join(" ");

  const tWords = timelineTitle.split(" ");
  const tHighlight = tWords.length > 1 ? tWords.pop() : "";
  const tNormal = tWords.join(" ");

  const sWords = skillsTitle.split(" ");
  const sHighlight = sWords.length > 1 ? sWords.pop() : "";
  const sNormal = sWords.join(" ");

  return (
    <section className="mt-20 grid gap-6 lg:grid-cols-3">
            <Reveal className="lg:col-span-2">
              <article className="h-full rounded-3xl border border-border/70 bg-card/40 p-7 sm:p-10">
                <h2 className="font-display text-2xl font-bold sm:text-3xl">Our story</h2>
                <p className="mt-5 text-sm leading-relaxed text-muted-foreground sm:text-base whitespace-pre-wrap">
                  {story}
                </p>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base whitespace-pre-wrap">
                  {difference}
                </p>
              </article>
            </Reveal>

            <Reveal delay={120}>
              <article className="h-full rounded-3xl border border-neon/30 bg-neon/[0.06] p-7 sm:p-10">
                <h2 className="font-display text-2xl font-bold sm:text-3xl">Our mission</h2>
                <p className="mt-5 text-sm leading-relaxed text-muted-foreground sm:text-base whitespace-pre-wrap">
                  {mission}
                </p>
                <p className="mt-6 font-display text-lg font-semibold text-neon text-glow">
                  One team. One system. Five services.
                </p>
              </article>
            </Reveal>
          </section>
  );
}
