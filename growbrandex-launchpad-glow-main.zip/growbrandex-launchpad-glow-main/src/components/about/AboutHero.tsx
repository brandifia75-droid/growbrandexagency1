
import { useSite, txt } from "@/lib/site-content";
import { Reveal } from "@/components/home/Reveal";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function AboutHero() {
  const { settings } = useSite();
  const eyebrow = txt(settings, "about", "eyebrow", "About us");
  const title = txt(settings, "about", "title", "We build brands that grow");
  const story = txt(settings, "about", "story", "We began by giving local business owners a more professional presence online — logos, identities and the small details that make a business look established. Over time we expanded into a full-service digital agency covering design, development and AI-powered content, because our clients kept asking us to handle more of their growth in one place.");
  const difference = txt(settings, "about", "difference", "What makes us different is that we don't just deliver a design or a video. We build a complete brand growth system — combining creative, technical and AI-driven content — so business owners can focus on running their business while we handle their online presence.");
  const mission = txt(settings, "about", "mission", "To help business owners grow real, recognizable brands — without needing five different freelancers.");
  const timelineTitle = txt(settings, "about", "timelineTitle", "How we grew");
  const skillsTitle = txt(settings, "about", "skillsTitle", "Where we're strongest");

  const words = title.split(" ");
  const titleHighlight = words.length > 1 ? words.pop() : "";
  const titleNormal = words.join(" ");

  const tWords = timelineTitle.split(" ");
  const tHighlight = tWords.length > 1 ? tWords.pop() : "";
  const tNormal = tWords.join(" ");

  const sWords = skillsTitle.split(" ");
  const sHighlight = sWords.length > 1 ? sWords.pop() : "";
  const sNormal = sWords.join(" ");

  return (
    <Reveal className="text-center">
            <p className="text-xs uppercase tracking-[0.3em] text-neon">{eyebrow}</p>
            <h1 className="mt-4 font-display text-4xl font-bold leading-[1.05] sm:text-6xl">
              {titleNormal}{" "}
              {titleHighlight && <span className="text-neon text-glow">{titleHighlight}</span>}
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground">
              GrowBrandex started as a small team helping local business owners look more
              professional online. Today we are a full-service digital growth agency.
            </p>
          </Reveal>
  );
}
