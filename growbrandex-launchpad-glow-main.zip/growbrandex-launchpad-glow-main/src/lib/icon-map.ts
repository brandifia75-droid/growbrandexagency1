import {
  Award,
  Bot,
  Brush,
  Camera,
  Clapperboard,
  Code2,
  Globe,
  Instagram,
  Megaphone,
  Palette,
  PenTool,
  Rocket,
  Share2,
  Sparkles,
  Star,
  Target,
  TrendingUp,
  Trophy,
  Video,
  Zap,
  type LucideIcon,
} from "lucide-react";

export const ICONS: Record<string, LucideIcon> = {
  Award,
  Bot,
  Brush,
  Camera,
  Clapperboard,
  Code2,
  Globe,
  Instagram,
  Megaphone,
  Palette,
  PenTool,
  Rocket,
  Share2,
  Sparkles,
  Star,
  Target,
  TrendingUp,
  Trophy,
  Video,
  Zap,
};

export const ICON_NAMES = Object.keys(ICONS);

export function icon(name?: string | null): LucideIcon {
  return (name && ICONS[name]) || Sparkles;
}
