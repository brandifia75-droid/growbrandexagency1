import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { getSiteContent } from "./content.functions";

export type SiteContent = Awaited<ReturnType<typeof getSiteContent>>;

export const siteContentQuery = queryOptions({
  queryKey: ["site-content"],
  queryFn: () => getSiteContent(),
  staleTime: 15_000,
});

export function useSite(): SiteContent {
  return useSuspenseQuery(siteContentQuery).data;
}

/** Read a string field from a site_settings group with a fallback. */
export function txt(
  settings: SiteContent["settings"],
  group: string,
  field: string,
  fallback = "",
): string {
  const v = settings?.[group]?.[field];
  return typeof v === "string" && v.trim() !== "" ? v : fallback;
}

export function num(
  settings: SiteContent["settings"],
  group: string,
  field: string,
  fallback = 0,
): number {
  const v = settings?.[group]?.[field];
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function list<T>(settings: SiteContent["settings"], group: string, fallback: T[]): T[] {
  const v = settings?.[group]?.["items"];
  return Array.isArray(v) && v.length > 0 ? (v as T[]) : fallback;
}


