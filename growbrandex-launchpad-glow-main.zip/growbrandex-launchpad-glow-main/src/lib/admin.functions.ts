import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

/**
 * Server-side authorization check. Uses the signed-in user's own token, so the
 * answer comes from the database (user_roles + RLS), never from the browser.
 */
export const checkAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (error) throw error;
    return { userId: context.userId, isAdmin: data === true };
  });

export const upsertProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(
    z.object({
      id: z.string().optional(),
      title: z.string().min(1, "Title is required"),
      description: z.string().optional().nullable(),
      category: z.string(),
      image_url: z.string().optional().nullable(),
      featured: z.boolean().optional(),
      sort_order: z.number().optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const payload = data.id ? data : { ...data, id: undefined };

    const { data: saved, error } = await context.supabase
      .from("projects")
      .upsert(payload)
      .select()
      .single();

    if (error) throw error;
    return saved;
  });

export const deleteProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const { error } = await context.supabase.from("projects").delete().eq("id", data.id);
    if (error) throw error;
    return { success: true };
  });

export const upsertService = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(
    z.object({
      id: z.string().optional(),
      title: z.string().min(1, "Title is required"),
      short_description: z.string().optional().nullable(),
      long_description: z.string().optional().nullable(),
      icon: z.string().optional().nullable(),
      sort_order: z.number().optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const payload = data.id ? data : { ...data, id: undefined };

    const { data: saved, error } = await context.supabase
      .from("services")
      .upsert(payload)
      .select()
      .single();

    if (error) throw error;
    return saved;
  });

export const deleteService = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const { error } = await context.supabase.from("services").delete().eq("id", data.id);
    if (error) throw error;
    return { success: true };
  });

export const upsertTestimonial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(
    z.object({
      id: z.string().optional(),
      quote: z.string().min(1, "Review text is required"),
      author: z.string().min(1, "Client name is required"),
      role: z.string().optional(),
      sort_order: z.number().optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const payload = data.id ? data : { ...data, id: undefined };

    const { data: saved, error } = await context.supabase
      .from("testimonials")
      .upsert(payload)
      .select()
      .single();

    if (error) throw error;
    return saved;
  });

export const deleteTestimonial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const { error } = await context.supabase.from("testimonials").delete().eq("id", data.id);
    if (error) throw error;
    return { success: true };
  });

export const listImages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const { data, error } = await context.supabase.storage.from("site-images").list("", {
      limit: 100,
      offset: 0,
      sortBy: { column: "created_at", order: "desc" },
    });

    // We also need to search in subfolders if applicable (like 'work/', 'brand/').
    // Wait, storage.list only lists a specific path. Let's list common paths:
    const paths = ["", "work", "brand", "hero"];
    const allFiles = [];

    for (const path of paths) {
      const { data: files } = await context.supabase.storage.from("site-images").list(path, {
        limit: 100,
      });
      if (files) {
        for (const file of files) {
          if (file.name !== ".emptyFolderPlaceholder" && file.id) {
            allFiles.push({
              ...file,
              fullPath: path ? `${path}/${file.name}` : file.name,
              url: `/api/public/img/${path ? `${path}/${file.name}` : file.name}`,
            });
          }
        }
      }
    }

    if (error) throw error;

    // Sort all by created_at desc
    allFiles.sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());

    return allFiles;
  });

export const uploadImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(
    z.object({
      path: z.string(),
      base64: z.string(),
      contentType: z.string(),
    }),
  )
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const buffer = Buffer.from(data.base64, "base64");

    const { data: uploadData, error } = await context.supabase.storage
      .from("site-images")
      .upload(data.path, buffer, {
        contentType: data.contentType,
        upsert: true,
      });

    if (error) throw error;
    return { path: uploadData.path, url: `/api/public/img/${uploadData.path}` };
  });

export const deleteImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(z.object({ path: z.string() }))
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const { error } = await context.supabase.storage.from("site-images").remove([data.path]);
    if (error) throw error;
    return { success: true };
  });

export const upsertWhyChooseUs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(
    z.object({
      id: z.string().optional(),
      title: z.string().min(1, "Title is required"),
      description: z.string().min(1, "Description is required"),
      source: z.string().optional().nullable(),
      sort_order: z.number().optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const payload = data.id ? data : { ...data, id: undefined };
    const { data: saved, error } = await context.supabase
      .from("awards")
      .upsert(payload)
      .select()
      .single();

    if (error) throw error;
    return saved;
  });

export const deleteWhyChooseUs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    const { data: isAdmin, error: rpcErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (rpcErr || !isAdmin) throw new Error("Unauthorized");

    const { error } = await context.supabase.from("awards").delete().eq("id", data.id);
    if (error) throw error;
    return { success: true };
  });

export const getSubmissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin, error: roleError } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleError || !isAdmin) throw new Error("Unauthorized");

    const { data, error } = await context.supabase
      .from("submissions")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) throw error;
    return data || [];
  });

export const markSubmissionRead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(z.object({ id: z.string(), status: z.string() }))
  .handler(async ({ data, context }) => {
    const { data: isAdmin, error: roleError } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleError || !isAdmin) throw new Error("Unauthorized");

    const { error } = await context.supabase
      .from("submissions")
      .update({ status: data.status })
      .eq("id", data.id);

    if (error) throw error;
    return { success: true };
  });

export const deleteSubmission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data, context }) => {
    const { data: isAdmin, error: roleError } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleError || !isAdmin) throw new Error("Unauthorized");

    const { error } = await context.supabase
      .from("submissions")
      .delete()
      .eq("id", data.id);

    if (error) throw error;
    return { success: true };
  });
