import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Json } from "@/integrations/supabase/types";

type UpdateInput = { key: string; value: Record<string, Json> };

const ALLOWED_KEYS = ["home", "stats", "about", "contact", "contact_page", "navigation", "page_sections"] as const;

/**
 * Admin-only update of a single site_settings group. The whole JSON object for
 * the group is replaced with the submitted object.
 */
export const updateSetting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: UpdateInput) => {
    if (
      !input ||
      typeof input.key !== "string" ||
      typeof input.value !== "object" ||
      input.value === null
    ) {
      throw new Error("Invalid input");
    }
    if (!(ALLOWED_KEYS as readonly string[]).includes(input.key)) {
      throw new Error(`Setting group "${input.key}" is not editable here`);
    }
    return input;
  })
  .handler(async ({ data, context }) => {
    const { data: isAdmin, error: roleError } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleError) throw roleError;
    if (isAdmin !== true) throw new Error("Forbidden");

    const { error } = await context.supabase
      .from("site_settings")
      .upsert({ key: data.key, value: data.value as Json }, { onConflict: "key" });
    if (error) throw error;

    return { ok: true, key: data.key };
  });
