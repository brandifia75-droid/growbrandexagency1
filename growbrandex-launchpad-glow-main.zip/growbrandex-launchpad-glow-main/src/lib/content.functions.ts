import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database, Json } from "@/integrations/supabase/types";

function publicClient() {
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  const url = process.env["SUPABASE_URL"]!;
  return createClient<Database>(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const getSiteContent = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();

  const [settingsRes, projectsRes, servicesRes, awardsRes, testimonialsRes] = await Promise.all([
    sb.from("site_settings").select("key, value"),
    sb
      .from("projects")
      .select("id, title, description, category, image_url, featured, sort_order")
      .order("sort_order", { ascending: true }),
    sb
      .from("services")
      .select("id, title, short_description, long_description, icon, sort_order")
      .order("sort_order", { ascending: true }),
    sb
      .from("awards")
      .select("id, title, source, description, sort_order")
      .order("sort_order", { ascending: true }),
    sb
      .from("testimonials")
      .select("id, quote, author, role, sort_order")
      .order("sort_order", { ascending: true }),
  ]);

  const settings: Record<string, Record<string, Json>> = {};
  for (const row of settingsRes.data ?? []) {
    settings[row.key] = (row.value ?? {}) as Record<string, Json>;
  }

  return {
    settings,
    projects: projectsRes.data ?? [],
    services: servicesRes.data ?? [],
    whyChooseUs: awardsRes.data ?? [],
    testimonials: testimonialsRes.data ?? [],
  };
});
