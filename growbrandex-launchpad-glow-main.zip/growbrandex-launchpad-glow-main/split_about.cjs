const fs = require('fs');
const aboutCode = fs.readFileSync('src/routes/about.tsx', 'utf8');

const heroMatch = aboutCode.match(/<Reveal className="text-center">[\s\S]*?<\/Reveal>/);
const storyMatch = aboutCode.match(/<section className="mt-20 grid gap-6 lg:grid-cols-3">[\s\S]*?<\/section>/);
const timelineMatch = aboutCode.match(/<section className="mt-24">[\s\S]*?<\/section>/);
const skillsMatch = aboutCode.match(/<section className="mt-16">[\s\S]*?<\/section>/);
const ctaMatch = aboutCode.match(/<Reveal className="mt-20 text-center" delay=\{80\}>[\s\S]*?<\/Reveal>/);

const createComponent = (name, body) => `
import { useSite, txt } from "@/lib/site-content";
import { Reveal } from "@/components/home/Reveal";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function ${name}() {
  const { settings } = useSite();
  const eyebrow = txt(settings, "about", "eyebrow", "About us");
  const title = txt(settings, "about", "title", "We build brands that grow");
  const story = txt(settings, "about", "story", "We began by giving local business owners a more professional presence online — logos, identities and the small details that make a business look established. Over time we expanded into a full-service digital agency covering design, development and AI-powered content, because our clients kept asking us to handle more of their growth in one place.");
  const difference = txt(settings, "about", "difference", "What makes us different is that we don't just deliver a design or a video. We build a complete brand growth system — combining creative, technical and AI-driven content — so business owners can focus on running their business while we handle their online presence.");
  const mission = txt(settings, "about", "mission", "To help business owners grow real, recognizable brands — without needing five different freelancers.");
  const timelineTitle = txt(settings, "about", "timelineTitle", "How we grew");
  const skillsTitle = txt(settings, "about", "skillsTitle", "Where we're strongest");

  const words = title.split(" ");
  const titleHighlight = words.length > 1 ? words.pop() : "";
  const titleNormal = words.join(" ");

  const tWords = timelineTitle.split(" ");
  const tHighlight = tWords.length > 1 ? tWords.pop() : "";
  const tNormal = tWords.join(" ");

  const sWords = skillsTitle.split(" ");
  const sHighlight = sWords.length > 1 ? sWords.pop() : "";
  const sNormal = sWords.join(" ");

  return (
    ${body}
  );
}
`;

fs.writeFileSync('src/components/about/AboutHero.tsx', createComponent('AboutHero', heroMatch[0]));
fs.writeFileSync('src/components/about/AboutStory.tsx', createComponent('AboutStory', storyMatch[0]));
fs.writeFileSync('src/components/about/AboutCTA.tsx', createComponent('AboutCTA', ctaMatch[0]));

// We need a special one for Timeline and Skills because they need milestones and skills data.
